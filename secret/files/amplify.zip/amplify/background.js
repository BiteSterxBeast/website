// Amplify service worker: turns the audio engine (tab-audio capture) on/off
// and remembers the latest effect settings.

const DEFAULT_FX = {
  reverb: 0, room: 3, echo: 0, delay: 350, spatial: "off", spin: 8,
  eq: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0], volume: 100,
};

async function getFx() {
  const { fx } = await chrome.storage.local.get("fx");
  return { ...DEFAULT_FX, ...(fx || {}) };
}

async function getCaptureTab() {
  const { captureTabId } = await chrome.storage.session.get("captureTabId");
  return captureTabId ?? null;
}

async function hasOffscreen() {
  const contexts = await chrome.runtime.getContexts({ contextTypes: ["OFFSCREEN_DOCUMENT"] });
  return contexts.length > 0;
}

function setStatus(tabId, on) {
  chrome.action.setBadgeBackgroundColor({ color: "#1ed760" });
  chrome.action.setBadgeTextColor?.({ color: "#000000" });
  chrome.action.setBadgeText({ tabId, text: on ? "ON" : "" });
  chrome.tabs.sendMessage(tabId, { type: "fxStatus", on }).catch(() => {});
}

async function start(tabId) {
  const streamId = await chrome.tabCapture.getMediaStreamId({ targetTabId: tabId });
  if (!(await hasOffscreen())) {
    await chrome.offscreen.createDocument({
      url: "offscreen.html",
      reasons: ["USER_MEDIA"],
      justification: "Apply EQ, reverb, echo, 8D and visualizer analysis to the Spotify tab's audio.",
    });
  }
  const fx = await getFx();
  await chrome.runtime.sendMessage({ target: "offscreen", type: "start", streamId, fx });
  await chrome.storage.session.set({ captureTabId: tabId });
  setStatus(tabId, true);
}

async function stop() {
  const tabId = await getCaptureTab();
  if (await hasOffscreen()) {
    try { await chrome.runtime.sendMessage({ target: "offscreen", type: "stop" }); } catch {}
    try { await chrome.offscreen.closeDocument(); } catch {}
  }
  await chrome.storage.session.remove("captureTabId");
  if (tabId != null) setStatus(tabId, false);
}

// Toolbar icon click = turn the audio engine on/off for this Spotify tab
chrome.action.onClicked.addListener(async (tab) => {
  if (!tab.url || !tab.url.startsWith("https://open.spotify.com/")) {
    chrome.tabs.create({ url: "https://open.spotify.com/" });
    return;
  }
  try {
    const current = await getCaptureTab();
    if (current === tab.id && (await hasOffscreen())) {
      await stop();
    } else {
      if (await hasOffscreen()) await stop();
      await start(tab.id);
    }
  } catch (e) {
    console.error(e);
    chrome.tabs.sendMessage(tab.id, { type: "fxError", message: String((e && e.message) || e) }).catch(() => {});
  }
});

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.target === "offscreen") return; // meant for the audio engine

  if (msg.type === "fx") {
    chrome.storage.local.set({ fx: msg.fx });
    return;
  }

  if (msg.type === "getStatus") {
    (async () => {
      const current = await getCaptureTab();
      sendResponse({ on: current != null && current === (sender.tab && sender.tab.id) && (await hasOffscreen()) });
    })();
    return true; // async response
  }

  if (msg.type === "captureEnded") stop();

  if (msg.type === "translate") {
    translate(msg.texts || [], msg.target || "en")
      .then((out) => sendResponse({ out }))
      .catch((e) => sendResponse({ error: String((e && e.message) || e) }));
    return true; // async response
  }
});

// Translate lyric lines with Google Translate's free web endpoint.
// Lines are sent in chunks joined by newlines, then split back apart.
async function translate(texts, target) {
  const out = new Array(texts.length).fill("");
  let i = 0;
  while (i < texts.length) {
    const chunk = [];
    let len = 0;
    while (i < texts.length && (chunk.length === 0 || len + texts[i].length < 1500)) {
      chunk.push(texts[i]);
      len += texts[i].length + 1;
      i++;
    }
    const q = chunk.map((t) => t.replace(/\n/g, " ") || "·").join("\n");
    const url = `https://translate.googleapis.com/translate_a/single?client=gtx&sl=auto&tl=${encodeURIComponent(target)}&dt=t&q=${encodeURIComponent(q)}`;
    const res = await fetch(url);
    if (!res.ok) throw new Error(`Translate failed (${res.status})`);
    const data = await res.json();
    const joined = (data[0] || []).map((seg) => seg[0] || "").join("");
    const parts = joined.split("\n");
    const start = i - chunk.length;
    chunk.forEach((orig, k) => (out[start + k] = orig.trim() ? (parts[k] || "").trim() : ""));
  }
  return out;
}

chrome.tabs.onRemoved.addListener(async (tabId) => {
  if ((await getCaptureTab()) === tabId) stop();
});
