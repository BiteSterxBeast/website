// Amplify core: the mod loader and shared APIs every mod uses.
// Runs inside the Spotify page (MAIN world) at document_start, before Spotify's own code.

(() => {
  if (window.Amplify) return;

  // ---------- Events ----------
  const listeners = {};
  function on(ev, fn) {
    (listeners[ev] ||= []).push(fn);
    return () => (listeners[ev] = (listeners[ev] || []).filter((f) => f !== fn));
  }
  function emit(ev, data) {
    (listeners[ev] || []).slice().forEach((fn) => {
      try { fn(data); } catch (e) { console.error("[Amplify]", ev, e); }
    });
  }

  // ---------- Storage (per-mod, saved in the page's localStorage) ----------
  const ls = {
    get(k) { try { return localStorage.getItem(k); } catch { return null; } },
    set(k, v) { try { localStorage.setItem(k, v); } catch {} },
  };
  function store(ns, defaults = {}) {
    const key = "amplify:" + ns;
    let data = structuredClone(defaults);
    try { Object.assign(data, JSON.parse(ls.get(key) || "{}")); } catch {}
    const save = () => ls.set(key, JSON.stringify(data));
    return {
      get: (k) => data[k],
      set(k, v) { data[k] = v; save(); },
      patch(obj) { Object.assign(data, obj); save(); },
      all: () => structuredClone(data),
      reset() { data = structuredClone(defaults); save(); },
    };
  }
  function resetAll() {
    try {
      Object.keys(localStorage).filter((k) => k.startsWith("amplify:")).forEach((k) => localStorage.removeItem(k));
    } catch {}
  }

  // ---------- Media hook (speed + pitch) ----------
  // Spotify's web player plays through an <audio> element and keeps forcing
  // playbackRate back to 1, so we intercept it at the prototype level.
  const proto = HTMLMediaElement.prototype;
  const rateDesc = Object.getOwnPropertyDescriptor(proto, "playbackRate");
  const els = new Set();
  const hooked = new WeakSet();
  const media = { rate: 1, keepPitch: true, els };

  function applyTo(el) {
    try {
      if (rateDesc.get.call(el) !== media.rate) rateDesc.set.call(el, media.rate);
      el.preservesPitch = media.keepPitch;
    } catch {}
  }
  function track(el) {
    els.add(el);
    applyTo(el);
    if (hooked.has(el)) return;
    hooked.add(el);
    ["loadedmetadata", "play", "playing", "ratechange"].forEach((ev) => el.addEventListener(ev, () => applyTo(el)));
  }
  Object.defineProperty(proto, "playbackRate", {
    configurable: true,
    enumerable: rateDesc.enumerable,
    get() { return rateDesc.get.call(this); },
    set() { track(this); rateDesc.set.call(this, media.rate); },
  });
  const origPlay = proto.play;
  proto.play = function (...args) { track(this); return origPlay.apply(this, args); };
  const origCreate = document.createElement;
  document.createElement = function (...args) {
    const el = origCreate.apply(this, args);
    if (el instanceof HTMLMediaElement) track(el);
    return el;
  };
  const OrigAudio = window.Audio;
  window.Audio = function (...args) { const el = new OrigAudio(...args); track(el); return el; };
  window.Audio.prototype = OrigAudio.prototype;

  media.set = (rate, keepPitch = media.keepPitch) => {
    media.rate = Math.min(4, Math.max(0.25, Math.round(rate * 100) / 100));
    media.keepPitch = !!keepPitch;
    els.forEach(applyTo);
    emit("speed", { rate: media.rate, keepPitch: media.keepPitch });
  };
  media.playing = () => [...els].some((el) => !el.paused && !el.ended);

  // ---------- Player API (now playing, skip, seek) ----------
  // Spotify registers media-key handlers with the browser; we keep a copy so mods can call them.
  const handlers = {};
  try {
    const ms = navigator.mediaSession;
    const origSet = ms.setActionHandler.bind(ms);
    ms.setActionHandler = (action, handler) => {
      handlers[action] = handler;
      return origSet(action, handler);
    };
  } catch {}

  const player = {
    meta() {
      const m = navigator.mediaSession && navigator.mediaSession.metadata;
      if (!m || !m.title) return null;
      const art = (m.artwork || []).slice().sort((a, b) => parseInt(b.sizes) - parseInt(a.sizes))[0];
      return { title: m.title, artist: m.artist || "", album: m.album || "", art: art ? art.src : "" };
    },
    next() {
      const b = document.querySelector('[data-testid="control-button-skip-forward"]');
      if (b && !b.disabled) return b.click();
      handlers.nexttrack && handlers.nexttrack({ action: "nexttrack" });
    },
    seek(seconds) {
      if (handlers.seekto) {
        try { return handlers.seekto({ action: "seekto", seekTime: seconds }); } catch {}
      }
      const el = [...els].find((e) => !e.paused);
      if (el) el.currentTime = seconds;
    },
    isPlaying: () => media.playing(),
    current: null,

    // Spotify track ID of the song playing. The player bar's title links to the album, not the
    // song, so we try three ways:
    //   1. a link that does contain the track (some layouts have one)
    //   2. the data inside Spotify's own player-bar component (React keeps it on the element)
    //   3. a lyrics download whose album cover matches the cover of the song playing
    trackId() {
      const links = document.querySelectorAll('[data-testid="context-item-info-title"] a, [data-testid="context-item-link"], [data-testid="now-playing-widget"] a, footer a');
      for (const a of links) {
        const href = decodeURIComponent(a.getAttribute("href") || "");
        const m = href.match(/spotify:track:([A-Za-z0-9]{22})/) || href.match(/\/track\/([A-Za-z0-9]{22})/);
        if (m) return remember(m[1]);
      }
      if (trackState.id) return trackState.id;
      return remember(reactTrackId() || coverTrackId());
    },
    // Cover image ID of the song playing (the same picture can come in different sizes; the end of the ID is the same)
    coverKey() {
      const m = navigator.mediaSession && navigator.mediaSession.metadata;
      const art = m && m.artwork && m.artwork[0] && m.artwork[0].src;
      return coverKeyOf(art);
    },

    // Where we are in the song, in seconds, smooth enough to time lyrics.
    // Spotify's time label only updates once a second, so we line it up with the
    // audio element's own clock (which is smooth) whenever the label ticks over.
    position() {
      const el = [...els].find((e) => !e.paused) || [...els][0];
      const offs = clock.offs;
      if (el && offs.length >= 3) {
        const s = offs.slice().sort((a, b) => a - b);
        if (s[s.length - 1] - s[0] < 0.4) return Math.max(0, el.currentTime - s[s.length >> 1]);
      }
      if (clock.label < 0) return 0;
      const elapsed = media.playing() ? ((performance.now() - clock.at) / 1000) * media.rate : 0;
      return clock.label + Math.min(elapsed, 1.05);
    },
  };

  // Remember the ID once found for this song, and don't accept the previous song's ID
  // in the first few seconds after a change (Spotify's data can lag a moment behind)
  const trackState = { id: null, prev: null, changedAt: 0 };
  function remember(id) {
    if (!id) return null;
    if (id === trackState.prev && Date.now() - trackState.changedAt < 3000) return null;
    trackState.id = id;
    return id;
  }

  function coverKeyOf(url) {
    const m = url && decodeURIComponent(url).match(/i\.scdn\.co\/image\/([0-9a-f]{40})/i);
    return m ? m[1].slice(-24).toLowerCase() : null;
  }

  // Look through the React data behind the player bar for "spotify:track:<id>"
  function scanForTrack(o, depth, seen) {
    if (!o || depth > 4) return null;
    if (typeof o === "string") {
      const m = o.match(/^spotify:track:([A-Za-z0-9]{22})$/);
      return m ? m[1] : null;
    }
    if (typeof o !== "object" || seen.has(o) || o.$$typeof || o instanceof Node) return null;
    seen.add(o);
    for (const k of Object.keys(o)) {
      if (k === "children" || k === "_owner" || k.startsWith("__")) continue;
      let v;
      try { v = o[k]; } catch { continue; }
      const id = scanForTrack(v, depth + 1, seen);
      if (id) return id;
    }
    return null;
  }
  function reactTrackId() {
    const starts = document.querySelectorAll('[data-testid="context-item-info-title"], [data-testid="now-playing-widget"], [data-testid="cover-art-image"]');
    for (const el of starts) {
      const key = Object.keys(el).find((k) => k.startsWith("__reactFiber$"));
      let f = key && el[key];
      for (let i = 0; f && i < 30; i++, f = f.return) {
        const id = scanForTrack(f.memoizedProps, 0, new Set());
        if (id) return id;
      }
    }
    return null;
  }

  // Lyrics downloads look like .../color-lyrics/v2/track/<id>/image/<cover url>
  const lyricsSeen = []; // [{ id, cover, at }]
  function coverTrackId() {
    const cover = player.coverKey();
    if (!cover) return null;
    for (let i = lyricsSeen.length - 1; i >= 0; i--) {
      const e = lyricsSeen[i];
      if (e.at < trackState.changedAt - 4000) break; // only downloads from around when this song started
      if (e.cover === cover && e.id !== trackState.prev) return e.id;
    }
    return null;
  }

  const clock = { label: -1, at: 0, offs: [] };
  const toSec = (t) => (t || "").replace("-", "").trim().split(":").reduce((acc, p) => acc * 60 + (+p || 0), 0);
  setInterval(() => {
    const p = document.querySelector('[data-testid="playback-position"]');
    if (!p) return;
    const s = toSec(p.textContent);
    if (s === clock.label) return;
    const el = [...els].find((e) => !e.paused);
    if (el && s === clock.label + 1) {
      clock.offs.push(el.currentTime - s);
      if (clock.offs.length > 6) clock.offs.shift();
    }
    clock.label = s;
    clock.at = performance.now();
  }, 40);

  let lastKey = null;
  setInterval(() => {
    const m = player.meta();
    const key = m ? m.title + "\u0000" + m.artist : null;
    if (key && key !== lastKey) {
      lastKey = key;
      player.current = m;
      clock.offs = [];
      trackState.prev = trackState.id;
      trackState.id = null;
      trackState.changedAt = Date.now();
      emit("track", m);
    }
  }, 400);

  // ---------- Network: catch the lyrics Spotify loads ----------
  // Spotify's web player downloads lyrics (with line timings) for the song you're playing.
  // We watch for those downloads so mods can use them, and remember the login headers
  // Spotify uses so we can ask for lyrics ourselves if Spotify hasn't loaded them yet.
  const origFetch = window.fetch;
  const net = { auth: null };
  window.fetch = async function (input, init) {
    const url = typeof input === "string" ? input : input && input.url ? input.url : String(input);
    try {
      if (url.includes("spclient")) {
        const h = init && init.headers ? new Headers(init.headers) : input instanceof Request ? input.headers : null;
        const auth = h && h.get("authorization");
        if (auth) {
          net.auth = {
            authorization: auth,
            "client-token": h.get("client-token") || "",
            "app-platform": h.get("app-platform") || "WebPlayer",
            "spotify-app-version": h.get("spotify-app-version") || "",
          };
        }
      }
    } catch {}
    const res = await origFetch.apply(this, arguments);
    try {
      const m = url.match(/color-lyrics\/v2\/track\/([A-Za-z0-9]{22})(?:\/image\/([^?]+))?/);
      if (m) net.noteLyrics(m[1], m[2], res.ok ? res.clone() : null);
    } catch {}
    return res;
  };
  net.noteLyrics = (id, coverUrl, res) => {
    lyricsSeen.push({ id, cover: coverKeyOf(coverUrl), at: Date.now() });
    if (lyricsSeen.length > 20) lyricsSeen.shift();
    if (res) res.json().then((data) => emit("lyrics:raw", { id, data })).catch(() => {});
    else emit("lyrics:raw", { id, data: null });
  };
  net.fetchLyrics = async (id) => {
    if (!net.auth || !id) return null;
    const headers = { accept: "application/json" };
    for (const k in net.auth) if (net.auth[k]) headers[k] = net.auth[k];
    try {
      const res = await origFetch(`https://spclient.wg.spotify.com/color-lyrics/v2/track/${id}?format=json&vocalRemoval=false&market=from_token`, { headers });
      if (!res.ok) return null;
      return await res.json();
    } catch {
      return null;
    }
  };

  // ---------- Talking to the extension (through bridge.js) ----------
  const toExt = (type, payload) => window.postMessage({ __amp: "toExt", type, payload }, "*");
  window.addEventListener("message", (e) => {
    if (e.source !== window || !e.data || e.data.__amp !== "toPage") return;
    emit("ext:" + e.data.type, e.data.payload);
  });

  // ---------- Audio engine (reverb, EQ, 8D, visualizer data) ----------
  const engine = { on: false, error: "" };
  const audio = {
    parts: {},
    set(modId, patch) {
      audio.parts[modId] = { ...(audio.parts[modId] || {}), ...patch };
      audio.push();
    },
    // Each mod contributes its own keys; a disabled mod falls back to neutral defaults
    effective() {
      const out = {};
      for (const mod of mods) {
        if (!mod.audioDefaults) continue;
        Object.assign(out, mod.audioDefaults, isEnabled(mod.id) ? audio.parts[mod.id] || {} : {});
      }
      return out;
    },
    _queued: false,
    push() {
      if (audio._queued) return;
      audio._queued = true;
      setTimeout(() => { audio._queued = false; toExt("audio", audio.effective()); }, 16);
    },
  };
  on("ext:status", (p) => {
    engine.on = !!(p && p.on);
    if (engine.on) { engine.error = ""; audio.push(); }
    emit("engine", engine);
  });
  on("ext:error", (p) => {
    engine.error = (p && p.message) || "unknown error";
    emit("engine", engine);
  });

  // ---------- Mod loader ----------
  const loader = store("loader", { disabled: [] });
  const mods = [];
  const isEnabled = (id) => !loader.get("disabled").includes(id);

  function register(mod) {
    if (!mod || !mod.id || mods.some((m) => m.id === mod.id)) return;
    mods.push(mod);
    try { mod.init && mod.init(Amplify); } catch (e) { console.error("[Amplify] init failed:", mod.id, e); }
    if (!isEnabled(mod.id)) {
      try { mod.disable && mod.disable(Amplify); } catch {}
    }
    audio.push();
    emit("mods", mods);
  }

  function setEnabled(id, enabled) {
    const disabled = new Set(loader.get("disabled"));
    enabled ? disabled.delete(id) : disabled.add(id);
    loader.set("disabled", [...disabled]);
    const mod = mods.find((m) => m.id === id);
    try { mod && (enabled ? mod.enable && mod.enable(Amplify) : mod.disable && mod.disable(Amplify)); } catch (e) { console.error(e); }
    audio.push();
    emit("mods", mods);
  }

  // ---------- Small UI helpers shared by mods ----------
  const ui = {
    el(html) {
      const t = origCreate.call(document, "template");
      t.innerHTML = html.trim();
      return t.content.firstElementChild;
    },
    // Keeps the custom slider fill in sync with its value
    range(input, value) {
      if (value !== undefined) input.value = value;
      const min = +input.min || 0, max = +input.max || 100, v = +input.value;
      const p = ((v - min) / (max - min)) * 100;
      let a = 0, b = p;
      if (input.hasAttribute("data-bipolar")) {
        const c = ((0 - min) / (max - min)) * 100;
        a = Math.min(p, c);
        b = Math.max(p, c);
      }
      input.style.setProperty("--a", a + "%");
      input.style.setProperty("--b", b + "%");
    },
    toast(text) { emit("toast", text); },
  };

  const Amplify = {
    version: "2.4.1",
    register, mods, isEnabled, setEnabled,
    on, emit, store, resetAll,
    media, player, engine, audio, toExt, ui, net,
  };
  window.Amplify = Amplify;
})();
