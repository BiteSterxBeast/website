// Mod: Visualizer. Opens as its own scene over Spotify's main view (like the lyrics screen),
// with four styles: bars, lines, a ring around the album art, and a waveform.
// Audio data comes from the audio engine.

Amplify.register({
  id: "visualizer",
  name: "Visualizer",
  description: "Full-screen music visualizer scene with four styles: bars, lines, a ring around the album art, and a waveform.",
  needsEngine: true,
  slot: "footer",
  icon: `<svg viewBox="0 0 24 24" width="18" height="18" fill="currentColor"><path d="M3 13h2v7H3zm4-5h2v12H7zm4-5h2v17h-2zm4 7h2v10h-2zm4-3h2v13h-2z"/></svg>`,

  STYLES: [
    { id: "bars", name: "Bars" },
    { id: "lines", name: "Lines" },
    { id: "ring", name: "Ring" },
    { id: "wave", name: "Wave" },
  ],

  init(A) {
    this.s = A.store("visualizer", { style: "bars", open: false });
    this.freq = new Float32Array(64);
    this.target = new Float32Array(64);
    this.peaks = new Float32Array(64);
    this.wave = new Float32Array(128);
    this.waveTarget = new Float32Array(128);
    this.lastFrame = 0;
    this.spin = 0;

    A.on("ext:viz", (d) => {
      if (!d) return;
      for (let i = 0; i < 64; i++) this.target[i] = (d.f[i] || 0) / 255;
      for (let i = 0; i < 128; i++) this.waveTarget[i] = (d.w[i] || 0) / 128;
      this.lastFrame = performance.now();
    });
    A.on("engine", () => { if (this.s.get("open")) A.toExt("viz", { on: true }); });

    document.addEventListener("keydown", (e) => {
      if (!A.isEnabled("visualizer")) return;
      if (e.altKey && (e.key === "v" || e.key === "V")) {
        e.preventDefault();
        this.toggle(A);
      } else if (e.key === "Escape" && this.s.get("open") && !document.fullscreenElement) {
        this.setOpen(A, false);
      }
    }, true);
  },

  disable(A) { if (this.scene) this.setOpen(A, false, false); },

  toggle(A) { this.setOpen(A, !this.s.get("open")); },

  setOpen(A, open, save = true) {
    if (save) this.s.set("open", open);
    if (!this.scene) return;
    if (!open && document.fullscreenElement === this.scene) document.exitFullscreen().catch(() => {});
    this.scene.classList.toggle("open", open);
    if (this.btn) {
      this.btn.classList.toggle("active", open);
      this.btn.querySelector("span").textContent = open ? "Close visualizer" : "Visualizer";
    }
    if (this.barBtn) this.barBtn.classList.toggle("active", open);
    A.toExt("viz", { on: open });
    if (open) { this.place(); this.renderInfo(A); this.loop(A); }
  },

  // Cover Spotify's main view (the same area the lyrics screen uses)
  mainView() {
    const sels = [".Root__main-view", "#main-view", '[data-testid="main-view-container"]', "main"];
    for (const s of sels) {
      const el = document.querySelector(s);
      if (el) {
        const r = el.getBoundingClientRect();
        if (r.width > 200 && r.height > 150) return r;
      }
    }
    return null;
  },
  place() {
    if (!this.scene || document.fullscreenElement === this.scene) return;
    const r = this.mainView();
    if (r) {
      Object.assign(this.scene.style, { left: r.left + "px", top: r.top + "px", width: r.width + "px", height: r.height + "px" });
    } else {
      const bar = document.querySelector('[data-testid="now-playing-bar"]') || document.querySelector("footer");
      const bottom = bar ? bar.getBoundingClientRect().top : window.innerHeight - 90;
      Object.assign(this.scene.style, { left: "8px", top: "8px", width: window.innerWidth - 16 + "px", height: Math.max(200, bottom - 16) + "px" });
    }
  },

  mount(root, A) {
    const css = document.createElement("style");
    css.textContent = `
      #amp-viz {
        position: fixed; z-index: 9990; display: none; overflow: hidden;
        border-radius: 8px; background: #121212; color: #fff; font-family: inherit;
      }
      #amp-viz.open { display: block; }
      #amp-viz:fullscreen { left: 0 !important; top: 0 !important; width: 100vw !important; height: 100vh !important; border-radius: 0; }
      #amp-viz canvas { position: absolute; inset: 0; width: 100%; height: 100%; display: block; }
      #amp-viz .av-head {
        position: absolute; top: 0; left: 0; right: 0; display: flex; align-items: center; justify-content: space-between;
        gap: 12px; padding: 20px 24px; background: linear-gradient(to bottom, rgba(0,0,0,.45), transparent);
      }
      #amp-viz .av-song { display: flex; align-items: center; gap: 14px; min-width: 0; }
      #amp-viz .av-song img { width: 56px; height: 56px; border-radius: 6px; object-fit: cover; box-shadow: 0 4px 16px rgba(0,0,0,.5); flex: none; background: #333; }
      #amp-viz .av-song img:not([src]) { visibility: hidden; }
      #amp-viz .av-song div { min-width: 0; }
      #amp-viz .av-title { font-size: 22px; font-weight: 800; letter-spacing: -.3px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
      #amp-viz .av-artist { font-size: 14px; color: rgba(255,255,255,.7); white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
      #amp-viz .av-ctl { display: flex; gap: 6px; flex: none; }
      #amp-viz .av-ctl button {
        border: none; border-radius: 999px; padding: 7px 14px; cursor: pointer;
        background: rgba(255,255,255,.1); color: #fff; font-family: inherit; font-size: 13px; font-weight: 700;
        backdrop-filter: blur(10px); transition: background .12s, transform .1s;
      }
      #amp-viz .av-ctl button:hover { background: rgba(255,255,255,.2); transform: scale(1.04); }
      #amp-viz .av-ctl button.active { background: #fff; color: #000; }
      #amp-viz .av-ctl .av-icon { padding: 7px 10px; }
      /* Bottom control bar: only shown in fullscreen, where Spotify's own bar is hidden */
      #amp-viz .av-bar {
        position: absolute; left: 0; right: 0; bottom: 0; display: none; align-items: center; gap: 20px;
        padding: 28px 28px 22px; background: linear-gradient(to top, rgba(0,0,0,.7), transparent);
        transition: opacity .3s;
      }
      #amp-viz:fullscreen .av-bar { display: grid; grid-template-columns: 1fr minmax(260px, 600px) 1fr; }
      #amp-viz .av-left { display: flex; align-items: center; gap: 10px; min-width: 0; color: rgba(255,255,255,.7); font-size: 13px; font-weight: 600; }
      #amp-viz .av-center { display: flex; flex-direction: column; align-items: center; gap: 8px; }
      #amp-viz .av-btns { display: flex; align-items: center; gap: 18px; }
      #amp-viz .av-btns button, #amp-viz .av-right button {
        display: grid; place-items: center; border: none; background: none; color: rgba(255,255,255,.8);
        cursor: pointer; padding: 6px; border-radius: 50%; transition: color .12s, transform .1s;
      }
      #amp-viz .av-btns button:hover, #amp-viz .av-right button:hover { color: #fff; transform: scale(1.08); }
      #amp-viz .av-btns .av-play { width: 44px; height: 44px; background: #fff; color: #000; }
      #amp-viz .av-btns .av-play:hover { color: #000; }
      #amp-viz .av-progress { display: flex; align-items: center; gap: 10px; width: 100%; font-size: 11px; color: rgba(255,255,255,.7); font-variant-numeric: tabular-nums; }
      #amp-viz .av-track { flex: 1; height: 4px; border-radius: 2px; background: rgba(255,255,255,.25); cursor: pointer; position: relative; }
      #amp-viz .av-track::before { content: ""; position: absolute; inset: -6px 0; }
      #amp-viz .av-fill { height: 100%; width: 0; border-radius: 2px; background: #fff; }
      #amp-viz .av-track:hover .av-fill { background: var(--amp-accent); }
      #amp-viz .av-right { display: flex; justify-content: flex-end; align-items: center; gap: 8px; }
      #amp-viz .av-right .av-tool { display: flex; gap: 6px; border-radius: 999px; padding: 8px 14px; background: rgba(255,255,255,.12); color: #fff; font-family: inherit; font-size: 13px; font-weight: 700; }
      #amp-viz .av-right .av-tool svg { color: var(--amp-accent); }
      #amp-viz .av-right .av-tool:hover { background: rgba(255,255,255,.22); transform: none; }
      #amp-viz .av-right .av-tool.open { background: var(--amp-accent); color: var(--amp-on-accent); }
      #amp-viz .av-right .av-tool.open svg { color: var(--amp-on-accent); }
      /* Hide controls and cursor after a few seconds without moving the mouse */
      #amp-viz:fullscreen.idle .av-bar, #amp-viz:fullscreen.idle .av-head { opacity: 0; }
      #amp-viz:fullscreen.idle { cursor: none; }
      #amp-viz .av-head { transition: opacity .3s; }
      #amp-viz:fullscreen .av-msg { bottom: 130px; }

      #amp-viz .av-msg {
        position: absolute; left: 50%; bottom: 28px; transform: translateX(-50%);
        padding: 9px 16px; border-radius: 999px; background: rgba(0,0,0,.6); font-size: 13px; font-weight: 600;
        white-space: nowrap; display: none;
      }
      #amp-viz .av-msg.show { display: block; }

      #amp-viz-btn {
        display: inline-flex; align-items: center; justify-content: center; width: 32px; height: 32px;
        background: none; border: none; border-radius: 16px; cursor: pointer; color: #b3b3b3; position: relative;
        transition: color .15s, transform .1s;
      }
      #amp-viz-btn:hover { color: #fff; transform: scale(1.05); }
      #amp-viz-btn.active { color: var(--amp-accent); }
      #amp-viz-btn.active::after { content: ""; position: absolute; bottom: 0; left: 50%; width: 4px; height: 4px; margin-left: -2px; border-radius: 50%; background: var(--amp-accent); }
    `;
    document.head.appendChild(css);

    this.scene = A.ui.el(`
      <div id="amp-viz">
        <canvas></canvas>
        <div class="av-head">
          <div class="av-song"><img alt=""><div><div class="av-title"></div><div class="av-artist"></div></div></div>
          <div class="av-ctl">
            ${this.STYLES.map((s) => `<button data-style="${s.id}">${s.name}</button>`).join("")}
            <button class="av-icon" data-fs title="Fullscreen">⛶</button>
            <button class="av-icon" data-close title="Close (Esc)">✕</button>
          </div>
        </div>
        <div class="av-msg">Click the Amplify icon in Chrome's toolbar to turn on the audio engine</div>
        <div class="av-bar">
          <div class="av-left"><span class="av-speed"></span></div>
          <div class="av-center">
            <div class="av-btns">
              <button data-act="prev" title="Previous"><svg viewBox="0 0 16 16" width="16" height="16" fill="currentColor"><path d="M3.3 1a.7.7 0 0 1 .7.7v5.15l9.95-5.744a.7.7 0 0 1 1.05.606v12.575a.7.7 0 0 1-1.05.607L4 9.149V14.3a.7.7 0 0 1-.7.7H1.7a.7.7 0 0 1-.7-.7V1.7a.7.7 0 0 1 .7-.7h1.6z"/></svg></button>
              <button data-act="play" class="av-play" title="Play/Pause"></button>
              <button data-act="next" title="Next"><svg viewBox="0 0 16 16" width="16" height="16" fill="currentColor"><path d="M12.7 1a.7.7 0 0 0-.7.7v5.15L2.05 1.107A.7.7 0 0 0 1 1.712v12.575a.7.7 0 0 0 1.05.607L12 9.149V14.3a.7.7 0 0 0 .7.7h1.6a.7.7 0 0 0 .7-.7V1.7a.7.7 0 0 0-.7-.7h-1.6z"/></svg></button>
            </div>
            <div class="av-progress"><span class="av-pos">0:00</span><div class="av-track"><div class="av-fill"></div></div><span class="av-dur">0:00</span></div>
          </div>
          <div class="av-right">
            <button class="av-tool" data-amp-toolbox title="Amplify toolbox (Alt+A)"><svg viewBox="0 0 24 24" width="16" height="16" fill="currentColor"><path d="M13.5 2 4 13.5h6.2L9 22l10-12h-6.4L13.5 2z"/></svg>Toolbox</button>
            <button data-act="exitfs" title="Exit fullscreen"><svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M9 4v5H4M15 4v5h5M9 20v-5H4M15 20v-5h5"/></svg></button>
          </div>
        </div>
      </div>`);
    document.body.appendChild(this.scene);
    this.canvas = this.scene.querySelector("canvas");
    this.ctx = this.canvas.getContext("2d");
    this.msg = this.scene.querySelector(".av-msg");

    const styleBtns = this.scene.querySelectorAll("[data-style]");
    const renderStyles = () => styleBtns.forEach((b) => b.classList.toggle("active", b.dataset.style === this.s.get("style")));
    styleBtns.forEach((b) => b.addEventListener("click", () => { this.s.set("style", b.dataset.style); renderStyles(); }));
    this.scene.querySelector("[data-close]").addEventListener("click", () => this.setOpen(A, false));
    this.scene.querySelector("[data-fs]").addEventListener("click", () => {
      if (document.fullscreenElement) document.exitFullscreen().catch(() => {});
      else this.scene.requestFullscreen().catch(() => {});
    });
    document.addEventListener("fullscreenchange", () => {
      setTimeout(() => this.place(), 50);
      this.wakeControls();
    });
    renderStyles();
    this.setupBar(A);

    // Button in the Amplify toolbox
    root.innerHTML = `<button class="amp-wide">${this.icon}<span>Visualizer</span></button>`;
    this.btn = root.querySelector("button");
    this.btn.addEventListener("click", () => this.toggle(A));

    // Button in Spotify's player bar, next to the Amplify button (like the lyrics button)
    this.barBtn = A.ui.el(`<button id="amp-viz-btn" title="Visualizer (Alt+V)">${this.icon}</button>`);
    this.barBtn.addEventListener("click", (e) => { e.stopPropagation(); this.toggle(A); });
    const placeBarBtn = () => {
      if (!A.isEnabled("visualizer")) { this.barBtn.remove(); return; }
      const amp = document.getElementById("amp-btn");
      if (amp && amp.parentElement && !amp.classList.contains("floating") && this.barBtn.nextSibling !== amp) {
        amp.parentElement.insertBefore(this.barBtn, amp);
      }
    };
    new MutationObserver(placeBarBtn).observe(document.body, { childList: true, subtree: true });
    A.on("mods", placeBarBtn);
    placeBarBtn();

    window.addEventListener("resize", () => this.s.get("open") && this.place());
    // Spotify's sidebars can be resized/collapsed, so keep the scene lined up
    setInterval(() => this.s.get("open") && this.place(), 500);

    A.on("track", (m) => { this.loadArt(m); this.renderInfo(A); });
    this.loadArt(A.player.current);

    if (this.s.get("open") && A.isEnabled("visualizer")) this.setOpen(A, true, false);
  },

  // ---------- Fullscreen control bar ----------
  setupBar(A) {
    const bar = this.scene.querySelector(".av-bar");
    const playBtn = bar.querySelector(".av-play");
    const fill = bar.querySelector(".av-fill");
    const posEl = bar.querySelector(".av-pos");
    const durEl = bar.querySelector(".av-dur");
    const speedEl = bar.querySelector(".av-speed");
    const toolBtn = bar.querySelector("[data-amp-toolbox]");
    const PLAY = `<svg viewBox="0 0 16 16" width="16" height="16" fill="currentColor"><path d="M3 1.713a.7.7 0 0 1 1.05-.607l10.89 6.288a.7.7 0 0 1 0 1.212L4.05 14.894A.7.7 0 0 1 3 14.288V1.713z"/></svg>`;
    const PAUSE = `<svg viewBox="0 0 16 16" width="16" height="16" fill="currentColor"><path d="M2.7 1a.7.7 0 0 0-.7.7v12.6a.7.7 0 0 0 .7.7h2.6a.7.7 0 0 0 .7-.7V1.7a.7.7 0 0 0-.7-.7H2.7zm8 0a.7.7 0 0 0-.7.7v12.6a.7.7 0 0 0 .7.7h2.6a.7.7 0 0 0 .7-.7V1.7a.7.7 0 0 0-.7-.7h-2.6z"/></svg>`;

    // Our buttons just press Spotify's real (hidden) buttons, so everything stays in sync
    const press = (testid) => {
      const b = document.querySelector(`[data-testid="${testid}"]`);
      if (b && !b.disabled) b.click();
    };
    bar.querySelector('[data-act="prev"]').onclick = () => press("control-button-skip-back");
    bar.querySelector('[data-act="next"]').onclick = () => press("control-button-skip-forward");
    playBtn.onclick = () => press("control-button-playpause");
    bar.querySelector('[data-act="exitfs"]').onclick = () => document.exitFullscreen().catch(() => {});
    toolBtn.onclick = (e) => { e.stopPropagation(); A.ui.toggleToolbox && A.ui.toggleToolbox(toolBtn); };
    A.on("toolbox", (open) => toolBtn.classList.toggle("open", open && !!document.fullscreenElement));

    // Read the song position from Spotify's own time labels
    const toSec = (t) => {
      if (!t) return 0;
      const neg = t.trim().startsWith("-");
      const s = t.replace("-", "").trim().split(":").reduce((acc, p) => acc * 60 + (+p || 0), 0);
      return neg ? -s : s;
    };
    const fmt = (s) => {
      s = Math.max(0, Math.round(s));
      const h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60), sec = String(s % 60).padStart(2, "0");
      return h ? `${h}:${String(m).padStart(2, "0")}:${sec}` : `${m}:${sec}`;
    };
    const times = () => {
      const p = document.querySelector('[data-testid="playback-position"]');
      const d = document.querySelector('[data-testid="playback-duration"]');
      const pos = toSec(p && p.textContent);
      let dur = toSec(d && d.textContent);
      if (dur < 0) dur = pos - dur; // Spotify can show time remaining, like -2:31
      return { pos, dur };
    };

    bar.querySelector(".av-track").addEventListener("click", (e) => {
      const r = e.currentTarget.getBoundingClientRect();
      const { dur } = times();
      if (dur) A.player.seek(((e.clientX - r.left) / r.width) * dur);
    });

    setInterval(() => {
      if (document.fullscreenElement !== this.scene) return;
      const { pos, dur } = times();
      posEl.textContent = fmt(pos);
      durEl.textContent = fmt(dur);
      fill.style.width = dur ? Math.min(100, (pos / dur) * 100) + "%" : "0%";
      const playing = A.player.isPlaying() ||
        ((document.querySelector('[data-testid="control-button-playpause"]') || {}).ariaLabel || "").toLowerCase().includes("pause");
      const icon = playing ? PAUSE : PLAY;
      if (playBtn.dataset.state !== String(playing)) { playBtn.innerHTML = icon; playBtn.dataset.state = String(playing); }
      speedEl.textContent = A.isEnabled("speed") && Math.abs(A.media.rate - 1) > 0.001 ? `⚡ ${A.media.rate.toFixed(2)}x` : "";
      // Auto-hide controls after 3s without mouse movement (unless the toolbox is open)
      const idle = performance.now() - this.lastMove > 3000 && !(A.ui.isToolboxOpen && A.ui.isToolboxOpen());
      this.scene.classList.toggle("idle", idle);
    }, 250);

    this.scene.addEventListener("mousemove", () => this.wakeControls());
    this.wakeControls();
  },

  wakeControls() {
    this.lastMove = performance.now();
    if (this.scene) this.scene.classList.remove("idle");
  },

  renderInfo(A) {
    if (!this.scene) return;
    const m = A.player.current;
    this.scene.querySelector(".av-title").textContent = m ? m.title : "Nothing playing";
    this.scene.querySelector(".av-artist").textContent = m ? m.artist : "";
    const img = this.scene.querySelector(".av-song img");
    if (m && m.art) img.src = m.art; else img.removeAttribute("src");
  },

  loadArt(m) {
    if (!m || !m.art || (this.art && this.art.src === m.art)) return;
    const img = new Image();
    img.src = m.art;
    img.onload = () => { this.art = img; this.bgKey = null; };
  },

  accent() {
    const now = performance.now();
    if (!this._acc || now - this._accAt > 1000) {
      this._acc = getComputedStyle(document.documentElement).getPropertyValue("--amp-accent").trim() || "#1ed760";
      if (!/^#[0-9a-f]{6}$/i.test(this._acc)) this._acc = "#1ed760";
      this._accAt = now;
    }
    return this._acc;
  },

  // Blurred, darkened album art behind everything (pre-rendered, redrawn only when needed)
  background(ctx, w, h, acc) {
    const key = `${w}x${h}|${this.art ? this.art.src : ""}|${acc}`;
    if (this.bgKey !== key) {
      this.bgKey = key;
      const dpr = window.devicePixelRatio || 1;
      const bg = (this.bg ||= document.createElement("canvas"));
      bg.width = Math.round(w * dpr);
      bg.height = Math.round(h * dpr);
      const b = bg.getContext("2d");
      b.setTransform(dpr, 0, 0, dpr, 0, 0);
      b.fillStyle = "#121212";
      b.fillRect(0, 0, w, h);
      if (this.art) {
        const s = Math.max(w, h) * 1.3;
        b.filter = "blur(70px) saturate(1.4) brightness(.45)";
        b.drawImage(this.art, (w - s) / 2, (h - s) / 2, s, s);
        b.filter = "none";
      } else {
        const g = b.createRadialGradient(w / 2, h * 0.6, 0, w / 2, h * 0.6, Math.max(w, h) * 0.7);
        g.addColorStop(0, acc + "40");
        g.addColorStop(1, "#12121200");
        b.fillStyle = g;
        b.fillRect(0, 0, w, h);
      }
      const shade = b.createLinearGradient(0, 0, 0, h);
      shade.addColorStop(0, "rgba(0,0,0,.25)");
      shade.addColorStop(1, "rgba(0,0,0,.55)");
      b.fillStyle = shade;
      b.fillRect(0, 0, w, h);
    }
    ctx.drawImage(this.bg, 0, 0, w, h);
  },

  loop(A) {
    if (this._raf) return;
    const frame = () => {
      this._raf = null;
      if (!this.s.get("open") || !A.isEnabled("visualizer")) return;
      this.draw(A);
      this._raf = requestAnimationFrame(frame);
    };
    this._raf = requestAnimationFrame(frame);
  },

  draw(A) {
    const c = this.canvas, ctx = this.ctx;
    const dpr = window.devicePixelRatio || 1;
    const w = c.clientWidth, h = c.clientHeight;
    if (!w || !h) return;
    if (c.width !== Math.round(w * dpr) || c.height !== Math.round(h * dpr)) {
      c.width = Math.round(w * dpr);
      c.height = Math.round(h * dpr);
    }
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);

    const live = A.engine.on && performance.now() - this.lastFrame < 500;
    for (let i = 0; i < 64; i++) {
      const t = live ? this.target[i] : 0;
      this.freq[i] += (t - this.freq[i]) * (t > this.freq[i] ? 0.55 : 0.18);
      this.peaks[i] = Math.max(this.freq[i], this.peaks[i] - 0.006);
    }
    for (let i = 0; i < 128; i++) {
      const t = live ? this.waveTarget[i] : 0;
      this.wave[i] += (t - this.wave[i]) * 0.5;
    }

    const acc = this.accent();
    this.background(ctx, w, h, acc);

    // Drawing area below the song header
    const top = 96, area = { x: 0, y: top, w, h: h - top };
    const style = this.s.get("style");

    // Synced lyrics from the Lyrics mod: drawn before the visuals (behind) or after them (in front)
    const L = A.lyricsLayer;
    const layer = L ? L.layer() : "off";
    const bottom = document.fullscreenElement === this.scene ? 120 : 24;
    const lyrArea = { x: 0, y: top, w, h: h - top - bottom };
    if (layer === "behind") L.draw(ctx, lyrArea, acc);

    if (style === "ring") this.drawRing(ctx, area, acc, A);
    else if (style === "wave") this.drawWave(ctx, area, acc);
    else if (style === "lines") this.drawLines(ctx, area, acc);
    else this.drawBars(ctx, area, acc);

    if (layer === "front") L.draw(ctx, lyrArea, acc);

    this.msg.classList.toggle("show", !A.engine.on);
  },

  drawBars(ctx, { x: ox, y: oy, w, h }, acc) {
    const n = 64, pad = Math.max(24, w * 0.04);
    const iw = w - pad * 2;
    const gap = Math.max(2, (iw / n) * 0.25);
    const bw = (iw - gap * (n - 1)) / n;
    const base = oy + h - 32, maxH = h * 0.78;
    const grad = ctx.createLinearGradient(0, base, 0, base - maxH);
    grad.addColorStop(0, acc);
    grad.addColorStop(1, "#ffffff");
    for (let i = 0; i < n; i++) {
      const x = ox + pad + i * (bw + gap);
      const bh = Math.max(3, this.freq[i] * maxH);
      ctx.fillStyle = grad;
      ctx.globalAlpha = 0.95;
      this.roundRect(ctx, x, base - bh, bw, bh, Math.min(4, bw / 2));
      ctx.globalAlpha = 0.7;
      ctx.fillStyle = "#fff";
      ctx.fillRect(x, base - Math.max(3, this.peaks[i] * maxH) - 5, bw, 2);
      // faint reflection
      ctx.globalAlpha = 0.12;
      ctx.fillStyle = acc;
      ctx.fillRect(x, base + 4, bw, Math.min(24, bh * 0.25));
    }
    ctx.globalAlpha = 1;
  },

  // Thin mirrored lines, like a voice-memo waveform
  drawLines(ctx, { x: ox, y: oy, w, h }, acc) {
    const n = 72;
    const span = Math.min(w * 0.8, 1400);
    const x0 = ox + (w - span) / 2;
    const step = span / (n - 1);
    const mid = oy + h / 2;
    const maxH = h * 0.36;
    ctx.lineCap = "butt";
    ctx.lineWidth = Math.max(2, Math.min(4, step * 0.22));
    ctx.strokeStyle = acc;
    ctx.shadowColor = acc;
    ctx.shadowBlur = 8;
    ctx.beginPath();
    for (let i = 0; i < n; i++) {
      // Spread bins out of order so neighbouring lines move differently (more organic look),
      // and taper the edges so it fades in and out like the reference
      const bin = (i * 23) % 64;
      const edge = Math.sin(((i + 0.5) / n) * Math.PI);
      const v = Math.max(0.03, this.freq[bin] * (0.35 + 0.65 * edge));
      const x = Math.round(x0 + i * step) + 0.5;
      const half = Math.max(3, v * maxH);
      ctx.moveTo(x, mid - half);
      ctx.lineTo(x, mid + half);
    }
    ctx.stroke();
    ctx.shadowBlur = 0;
  },

  drawRing(ctx, { x: ox, y: oy, w, h }, acc, A) {
    const cx = ox + w / 2, cy = oy + h * 0.47;
    const bass = (this.freq[0] + this.freq[1] + this.freq[2] + this.freq[3]) / 4;
    const r0 = Math.min(h * 0.22, w * 0.16) * (1 + bass * 0.08);
    const maxLen = Math.min(h * 0.2, 170);
    const n = 128;

    const glow = ctx.createRadialGradient(cx, cy, r0 * 0.8, cx, cy, r0 + maxLen);
    glow.addColorStop(0, acc + "55");
    glow.addColorStop(1, acc + "00");
    ctx.fillStyle = glow;
    ctx.beginPath();
    ctx.arc(cx, cy, r0 + maxLen, 0, Math.PI * 2);
    ctx.fill();

    ctx.lineCap = "round";
    ctx.strokeStyle = acc;
    ctx.lineWidth = Math.max(2, ((Math.PI * 2 * r0) / n) * 0.55);
    for (let i = 0; i < n; i++) {
      const bin = i < 64 ? i : 127 - i;
      const v = this.freq[bin];
      const a = (i / n) * Math.PI * 2 - Math.PI / 2;
      const len = 4 + v * maxLen;
      const cos = Math.cos(a), sin = Math.sin(a);
      ctx.globalAlpha = 0.55 + v * 0.45;
      ctx.beginPath();
      ctx.moveTo(cx + cos * (r0 + 6), cy + sin * (r0 + 6));
      ctx.lineTo(cx + cos * (r0 + 6 + len), cy + sin * (r0 + 6 + len));
      ctx.stroke();
    }
    ctx.globalAlpha = 1;

    if (A.player.isPlaying()) this.spin += 0.004;
    ctx.save();
    ctx.beginPath();
    ctx.arc(cx, cy, r0, 0, Math.PI * 2);
    ctx.clip();
    if (this.art) {
      ctx.translate(cx, cy);
      ctx.rotate(this.spin);
      ctx.drawImage(this.art, -r0, -r0, r0 * 2, r0 * 2);
    } else {
      ctx.fillStyle = "#222";
      ctx.fillRect(cx - r0, cy - r0, r0 * 2, r0 * 2);
    }
    ctx.restore();
    ctx.strokeStyle = "rgba(255,255,255,.25)";
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.arc(cx, cy, r0, 0, Math.PI * 2);
    ctx.stroke();
    ctx.fillStyle = "rgba(0,0,0,.8)";
    ctx.beginPath();
    ctx.arc(cx, cy, Math.max(4, r0 * 0.07), 0, Math.PI * 2);
    ctx.fill();
  },

  drawWave(ctx, { x: ox, y: oy, w, h }, acc) {
    const mid = oy + h * 0.5, amp = h * 0.36;
    const n = this.wave.length;
    const path = (scale) => {
      ctx.beginPath();
      for (let i = 0; i < n; i++) {
        const x = ox + (i / (n - 1)) * w;
        const y = mid + this.wave[i] * amp * scale;
        i ? ctx.lineTo(x, y) : ctx.moveTo(x, y);
      }
    };
    ctx.lineJoin = "round";
    ctx.shadowColor = acc;
    ctx.shadowBlur = 18;
    ctx.strokeStyle = acc;
    ctx.globalAlpha = 0.35;
    ctx.lineWidth = 8;
    path(1); ctx.stroke();
    ctx.globalAlpha = 1;
    ctx.lineWidth = 3;
    path(1); ctx.stroke();
    ctx.shadowBlur = 0;
    ctx.strokeStyle = "rgba(255,255,255,.35)";
    ctx.lineWidth = 1.5;
    path(-0.6); ctx.stroke();
  },

  roundRect(ctx, x, y, w, h, r) {
    ctx.beginPath();
    ctx.moveTo(x, y + h);
    ctx.lineTo(x, y + r);
    ctx.quadraticCurveTo(x, y, x + r, y);
    ctx.lineTo(x + w - r, y);
    ctx.quadraticCurveTo(x + w, y, x + w, y + r);
    ctx.lineTo(x + w, y + h);
    ctx.closePath();
    ctx.fill();
  },
});
