// Mod: Lyrics. Restyle ("retexture") lyrics, show synced lyrics in the visualizer
// (behind or in front of the visuals), translate them, and fix wrong lines or translations.
//
// Lyrics come from Spotify itself: core.js catches the lyrics Spotify downloads for the
// song you're playing (with a start time for every line). Nothing is pulled from other sites.

Amplify.register({
  id: "lyrics",
  name: "Lyrics",
  description: "Restyle Spotify's lyrics, show synced lyrics behind or in front of the visualizer, translate them, and fix wrong lines or translations.",
  icon: `<svg viewBox="0 0 24 24" width="18" height="18" fill="currentColor"><path d="M4 5h12v2H4zm0 4h12v2H4zm0 4h8v2H4zm14.5-6v8.3a3 3 0 1 0 2 2.7V9h2V7h-4z"/></svg>`,

  // Spotify labels each lyric line with this (the text sits in the first div inside it)
  LINE: '[data-testid="lyrics-line"], [data-testid="fullscreen-lyric"]',

  FONTS: {
    spotify: { name: "Spotify", css: "" },
    rounded: { name: "Rounded", css: 'ui-rounded, "Arial Rounded MT Bold", "Varela Round", "Nunito", system-ui, sans-serif' },
    serif: { name: "Serif", css: 'Georgia, "Times New Roman", serif' },
    mono: { name: "Mono", css: 'Consolas, "Cascadia Mono", "Courier New", monospace' },
    impact: { name: "Impact", css: 'Impact, "Arial Black", "Haettenschweiler", sans-serif' },
    comic: { name: "Comic", css: '"Comic Sans MS", "Comic Neue", cursive' },
  },
  LANGS: [
    ["en", "English"], ["es", "Spanish"], ["pt", "Portuguese"], ["fr", "French"], ["de", "German"],
    ["it", "Italian"], ["ja", "Japanese"], ["ko", "Korean"], ["zh-CN", "Chinese"], ["ru", "Russian"],
    ["ar", "Arabic"], ["hi", "Hindi"], ["tl", "Tagalog"], ["vi", "Vietnamese"], ["tr", "Turkish"], ["nl", "Dutch"],
  ],

  init(A) {
    this.s = A.store("lyrics", {
      font: "spotify", size: 100, color: "theme", custom: "#ffffff", glow: true, caps: false, align: "center",
      applySpotify: true,
      layer: "behind", opacity: 70, vizTrans: true,
      transOn: false, lang: "en",
      edits: {}, // trackId -> { lines: {i: text}, trans: {i: text} }
    });
    this.cache = {};       // trackId -> parsed lyrics
    this.trans = {};       // "trackId:lang" -> [lines]
    try { this.trans = JSON.parse(localStorage.getItem("amplify:lyricsTrans") || "{}"); } catch {}
    this.curId = null;
    this.status = "Play a song to load its lyrics.";

    A.on("lyrics:raw", ({ id, data }) => {
      this.cache[id] = this.parse(data);
      if (id === this.curId || id === A.player.trackId()) this.setCurrent(A, id);
    });
    // If we couldn't work out the song yet, keep checking (a lyrics download may arrive later)
    setInterval(() => {
      if (this.curId || !A.player.current || !A.isEnabled("lyrics")) return;
      const id = A.player.trackId();
      if (id) { this.curId = id; this.cache[id] ? this.setCurrent(A, id) : this.loadFor(A, id); }
    }, 1500);
    A.on("track", () => this.onTrack(A));
    A.on("ext:translated", (p) => this.onTranslated(A, p));

    // Let the visualizer draw lyrics in its scene
    A.lyricsLayer = {
      layer: () => (A.isEnabled("lyrics") ? this.s.get("layer") : "off"),
      draw: (ctx, area, acc) => this.drawOnCanvas(A, ctx, area, acc),
    };

    const ready = () => {
      this.styleEl = document.createElement("style");
      this.styleEl.id = "amp-lyrics-style";
      document.head.appendChild(this.styleEl);
      this.applyStyle(A);
      let queued = false;
      new MutationObserver(() => {
        if (queued) return;
        queued = true;
        requestAnimationFrame(() => { queued = false; this.decorateSpotify(A); });
      }).observe(document.body, { childList: true, subtree: true, characterData: true });
    };
    if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", ready);
    else ready();
  },

  enable(A) { this.applyStyle(A); this.decorateSpotify(A); },
  disable(A) { this.applyStyle(A); this.decorateSpotify(A); },

  // ---------- Loading lyrics ----------
  parse(data) {
    const ly = data && data.lyrics;
    if (!ly || !Array.isArray(ly.lines)) return { lines: [], synced: false, missing: true };
    const hex = (n) => (n == null ? null : "#" + ((n >>> 0) & 0xffffff).toString(16).padStart(6, "0"));
    const c = data.colors || {};
    return {
      lines: ly.lines.map((l) => ({ t: +l.startTimeMs || 0, text: (l.words || "").trim() })),
      synced: ly.syncType !== "UNSYNCED",
      lang: ly.language || "",
      colors: { bg: hex(c.background), text: hex(c.text), hi: hex(c.highlightText) },
    };
  },

  async onTrack(A) {
    this.curId = null;
    this.status = "Loading lyrics…";
    A.emit("lyrics:changed");
    // The title link can update a moment after the song changes, so check a few times
    let id = null;
    for (let i = 0; i < 10 && !id; i++) {
      await new Promise((r) => setTimeout(r, 250));
      id = A.player.trackId();
    }
    if (!id) {
      this.status = "Waiting for Spotify to load this song's lyrics. If nothing shows up, open Spotify's lyrics screen (the mic button) once.";
      return A.emit("lyrics:changed");
    }
    this.curId = id;
    if (this.cache[id]) return this.setCurrent(A, id);
    this.loadFor(A, id);
  },

  async loadFor(A, id) {
    // Give Spotify a moment to load them itself, then ask for them directly
    await new Promise((r) => setTimeout(r, 1200));
    if (this.cache[id]) return this.setCurrent(A, id);
    if (this.curId !== id) return;
    const data = await A.net.fetchLyrics(id);
    if (this.curId !== id) return;
    if (data) { this.cache[id] = this.parse(data); this.setCurrent(A, id); }
    else { this.cache[id] = { lines: [], synced: false }; this.status = "No lyrics on Spotify for this song."; A.emit("lyrics:changed"); }
  },

  setCurrent(A, id) {
    this.curId = id;
    const c = this.cache[id];
    this.status = !c || !c.lines.length ? "No lyrics on Spotify for this song." : c.synced ? "" : "These lyrics aren't time-synced, so they won't show in the visualizer.";
    this.translateCurrent(A);
    A.emit("lyrics:changed");
    this.decorateSpotify(A);
  },

  // Lines with your corrections applied
  lines() {
    const c = this.cache[this.curId];
    if (!c) return [];
    const ed = (this.s.get("edits")[this.curId] || {}).lines || {};
    return c.lines.map((l, i) => ({ ...l, orig: l.text, text: ed[i] != null ? ed[i] : l.text, edited: ed[i] != null }));
  },
  transLines() {
    if (!this.s.get("transOn") || !this.curId) return null;
    const base = this.trans[this.curId + ":" + this.s.get("lang")];
    if (!base) return null;
    const ed = (this.s.get("edits")[this.curId] || {}).trans || {};
    return base.map((t, i) => (ed[i] != null ? ed[i] : t));
  },
  saveEdit(A, kind, i, text) {
    const edits = this.s.get("edits");
    const e = (edits[this.curId] ||= { lines: {}, trans: {} });
    (e[kind] ||= {});
    const orig = kind === "lines" ? (this.cache[this.curId].lines[i] || {}).text : (this.trans[this.curId + ":" + this.s.get("lang")] || [])[i];
    if (text == null || text === orig) delete e[kind][i];
    else e[kind][i] = text;
    this.s.set("edits", edits);
    A.emit("lyrics:changed");
    this.decorateSpotify(A, true);
  },

  indexAt(lines, sec) {
    const ms = sec * 1000 + 150; // switch a hair early so it feels on time
    let lo = 0, hi = lines.length - 1, ans = -1;
    while (lo <= hi) {
      const mid = (lo + hi) >> 1;
      if (lines[mid].t <= ms) { ans = mid; lo = mid + 1; } else hi = mid - 1;
    }
    return ans;
  },

  // ---------- Translation ----------
  translateCurrent(A) {
    if (!this.s.get("transOn") || !this.curId) return;
    const c = this.cache[this.curId];
    if (!c || !c.lines.length) return;
    const lang = this.s.get("lang");
    const key = this.curId + ":" + lang;
    if (this.trans[key] || this.pending === key) return;
    if (c.lang && lang.split("-")[0] === c.lang.split("-")[0]) {
      this.trans[key] = c.lines.map(() => ""); // already in that language
      return;
    }
    this.pending = key;
    this.status = "Translating…";
    A.emit("lyrics:changed");
    A.toExt("translate", { key, target: lang, texts: c.lines.map((l) => (l.text === "♪" ? "" : l.text)) });
  },
  onTranslated(A, p) {
    if (!p || p.key !== this.pending) return;
    this.pending = null;
    if (p.out) {
      this.trans[p.key] = p.out;
      const keys = Object.keys(this.trans);
      if (keys.length > 60) delete this.trans[keys[0]]; // keep the cache small
      try { localStorage.setItem("amplify:lyricsTrans", JSON.stringify(this.trans)); } catch {}
      this.status = "";
    } else {
      this.status = "Translation failed: " + (p.error || "unknown error");
    }
    A.emit("lyrics:changed");
    this.decorateSpotify(A, true);
  },

  // ---------- Retexture ----------
  activeColor(A) {
    const c = this.s.get("color");
    if (c === "white") return "#ffffff";
    if (c === "custom") return this.s.get("custom");
    if (c === "album") {
      const cur = this.cache[this.curId];
      return (cur && cur.colors && cur.colors.hi) || "#ffffff";
    }
    return getComputedStyle(document.documentElement).getPropertyValue("--amp-accent").trim() || "#1ed760";
  },
  fontCss() { return (this.FONTS[this.s.get("font")] || this.FONTS.spotify).css; },

  // Restyle Spotify's own lyrics screen
  applyStyle(A) {
    if (!this.styleEl) return;
    if (!A.isEnabled("lyrics") || !this.s.get("applySpotify")) { this.styleEl.textContent = ""; return; }
    const font = this.fontCss();
    const color = this.activeColor(A);
    const size = this.s.get("size") / 100;
    const LINE = this.LINE.split(",").map((x) => x.trim());
    const all = (suffix) => LINE.map((l) => l + suffix).join(", ");
    this.styleEl.textContent = `
      [style*="--lyrics-color-active"] {
        --lyrics-color-active: ${color} !important;
        --lyrics-color-passed: color-mix(in srgb, ${color} 55%, #ffffff) !important;
      }
      ${all("")} { text-align: ${this.s.get("align")} !important; }
      ${all(" > div")}, ${all("")} {
        ${font ? `font-family: ${font} !important;` : ""}
        font-size: calc(clamp(1.5rem, 3.2vw, 2.5rem) * ${size}) !important; line-height: 1.25 !important;
        ${this.s.get("caps") ? "text-transform: uppercase !important;" : ""}
        ${this.s.get("glow") ? "text-shadow: 0 0 18px color-mix(in srgb, currentColor 55%, transparent) !important;" : ""}
      }
      ${all(" .amp-lyr-trans")} {
        display: block; margin-top: 4px; font-size: .55em; font-weight: 600; opacity: .7;
        text-transform: none; font-style: italic;
      }
    `;
  },

  // Put corrections and translations into Spotify's lyrics screen
  decorateSpotify(A, force = false) {
    const els = document.querySelectorAll(this.LINE);
    if (!els.length) return;
    const on = A.isEnabled("lyrics");
    const lines = on ? this.lines() : [];
    const trans = on ? this.transLines() : null;
    let j = 0;
    els.forEach((el) => {
      const holder = el.querySelector(":scope > div") || el;
      // Only touch the text nodes' values (never add/remove Spotify's own nodes), so Spotify's page doesn't break
      const textNodes = [...holder.childNodes].filter((n) => n.nodeType === 3);
      if (!textNodes.length) return;
      const own = textNodes.map((n) => n.nodeValue).join("").trim();
      // Remember Spotify's original text; if Spotify changed it since we last looked, that's the new original
      if (!el.dataset.ampOrig || own !== el.dataset.ampShown) el.dataset.ampOrig = own;
      const orig = el.dataset.ampOrig;
      // match this element to a line by its original text, searching ahead
      let idx = -1;
      for (let k = j; k < Math.min(lines.length, j + 6); k++) {
        if (lines[k].orig === orig) { idx = k; break; }
      }
      if (idx >= 0) j = idx + 1;
      const want = idx >= 0 ? lines[idx].text : orig;
      const tr = idx >= 0 && trans ? trans[idx] : "";

      if (own !== want) {
        textNodes[0].nodeValue = want;
        textNodes.slice(1).forEach((n) => (n.nodeValue = ""));
      }
      el.dataset.ampShown = want;

      let tEl = holder.querySelector(".amp-lyr-trans");
      if (tr && tr !== want) {
        if (!tEl) { tEl = document.createElement("span"); tEl.className = "amp-lyr-trans"; holder.appendChild(tEl); }
        if (tEl.textContent !== tr) tEl.textContent = tr;
      } else if (tEl) tEl.remove();
    });
  },

  // ---------- Lyrics in the visualizer scene ----------
  wrap(ctx, text, maxW) {
    const words = text.split(/\s+/);
    const rows = [];
    let row = "";
    for (const w of words) {
      const test = row ? row + " " + w : w;
      if (ctx.measureText(test).width > maxW && row) { rows.push(row); row = w; }
      else row = test;
    }
    if (row) rows.push(row);
    return rows;
  },

  drawOnCanvas(A, ctx, { x, y, w, h }, acc) {
    const c = this.cache[this.curId];
    if (!c || !c.synced || !c.lines.length) return;
    const lines = this.lines();
    const trans = this.s.get("vizTrans") ? this.transLines() : null;
    const pos = A.player.position();
    const i = this.indexAt(lines, pos);
    const color = this.s.get("color") === "theme" ? acc : this.activeColor(A);
    const fam = this.fontCss() || 'system-ui, "Segoe UI", sans-serif';
    const caps = (t) => (this.s.get("caps") ? t.toUpperCase() : t);
    const big = Math.max(20, Math.min(h * 0.085, w * 0.055) * (this.s.get("size") / 100));
    const small = big * 0.55;
    const align = this.s.get("align");
    const tx = align === "left" ? x + w * 0.08 : x + w / 2;
    const maxW = w * 0.84;

    ctx.save();
    ctx.globalAlpha = this.s.get("opacity") / 100;
    ctx.textAlign = align === "left" ? "left" : "center";
    ctx.textBaseline = "middle";

    const cur = i >= 0 ? lines[i] : null;
    const text = cur ? caps(cur.text || "♪") : "♪";
    ctx.font = `800 ${big}px ${fam}`;
    const rows = this.wrap(ctx, text, maxW);
    const rowH = big * 1.15;
    const tr = cur && trans ? trans[i] : "";
    const blockH = rows.length * rowH + (tr ? small * 1.4 : 0);
    let ty = y + h / 2 - blockH / 2 + rowH / 2;

    // previous line (faded, above)
    if (i > 0) {
      ctx.font = `700 ${small}px ${fam}`;
      ctx.fillStyle = "rgba(255,255,255,.35)";
      ctx.fillText(caps(lines[i - 1].text || "♪"), tx, ty - rowH * 0.95, maxW);
    }

    // current line, with a karaoke-style fill that sweeps across as the line plays
    const next = lines[i + 1];
    const start = cur ? cur.t / 1000 : 0;
    const end = next ? next.t / 1000 : start + 4;
    const p = cur ? Math.min(1, Math.max(0, (pos - start) / Math.max(0.3, Math.min(end - start, 8) * 0.9))) : 0;
    ctx.font = `800 ${big}px ${fam}`;
    const widths = rows.map((r) => ctx.measureText(r).width);
    const total = widths.reduce((a, b) => a + b, 0);
    let fillLeft = p * total;
    rows.forEach((r, k) => {
      const rw = widths[k];
      const left = align === "left" ? tx : tx - rw / 2;
      ctx.fillStyle = "rgba(255,255,255,.45)";
      ctx.fillText(r, tx, ty);
      const f = Math.max(0, Math.min(rw, fillLeft));
      fillLeft -= rw;
      if (f > 0) {
        ctx.save();
        ctx.beginPath();
        ctx.rect(left - 4, ty - rowH / 2 - 10, f + 4, rowH + 20);
        ctx.clip();
        if (this.s.get("glow")) { ctx.shadowColor = color; ctx.shadowBlur = big * 0.5; }
        ctx.fillStyle = color;
        ctx.fillText(r, tx, ty);
        ctx.restore();
      }
      ty += rowH;
    });

    // translation under the current line
    if (tr && tr !== (cur && cur.text)) {
      ctx.font = `italic 600 ${small}px ${fam}`;
      ctx.fillStyle = "rgba(255,255,255,.75)";
      ctx.fillText(tr, tx, ty - rowH / 2 + small * 1.2, maxW);
      ty += small * 1.4;
    }

    // next line (faded, below)
    if (next) {
      ctx.font = `700 ${small}px ${fam}`;
      ctx.fillStyle = "rgba(255,255,255,.35)";
      ctx.fillText(caps(next.text || "♪"), tx, ty - rowH / 2 + small * 1.3, maxW);
    }
    ctx.restore();
  },

  // ---------- Lyrics tab ----------
  mount(root, A) {
    root.innerHTML = `
      <style>
        #amp-panel .ly-status { color: var(--amp-sub); font-size: 12px; margin-bottom: 10px; }
        #amp-panel .ly-status:empty { display: none; }
        #amp-panel .ly-sel {
          width: 100%; padding: 7px 10px; border-radius: 7px; border: 1px solid #3e3e3e; background: var(--amp-card);
          color: #fff; font-family: inherit; font-size: 12px; outline: none;
        }
        #amp-panel .ly-colors { display: flex; align-items: center; gap: 6px; }
        #amp-panel .ly-colors .amp-chip { flex: 1; }
        #amp-panel .ly-colors input[type=color] { width: 34px; height: 30px; border: none; border-radius: 6px; padding: 0; background: none; cursor: pointer; }
        #amp-panel .ly-list { max-height: 260px; overflow-y: auto; margin: 0 -4px; padding: 0 4px; }
        #amp-panel .ly-line { display: grid; grid-template-columns: 34px 1fr auto; gap: 6px; padding: 5px 4px; border-radius: 6px; align-items: start; }
        #amp-panel .ly-line.now { background: rgba(255,255,255,.07); }
        #amp-panel .ly-line.now .ly-txt { color: var(--amp-accent); }
        #amp-panel .ly-time { color: var(--amp-sub); font-size: 10px; font-variant-numeric: tabular-nums; padding-top: 2px; cursor: pointer; }
        #amp-panel .ly-time:hover { color: #fff; }
        #amp-panel .ly-txt, #amp-panel .ly-tr { cursor: text; border-radius: 4px; word-break: break-word; }
        #amp-panel .ly-txt { font-size: 12.5px; font-weight: 600; }
        #amp-panel .ly-tr { font-size: 11px; color: var(--amp-sub); font-style: italic; margin-top: 1px; }
        #amp-panel .ly-txt:hover, #amp-panel .ly-tr:hover { background: rgba(255,255,255,.06); }
        #amp-panel .ly-edited { color: #ffd166 !important; }
        #amp-panel .ly-line input {
          width: 100%; padding: 4px 6px; border-radius: 5px; border: 1px solid var(--amp-accent); background: #2a2a2a;
          color: #fff; font-family: inherit; font-size: 12px; outline: none;
        }
        #amp-panel .ly-undo { border: none; background: none; color: var(--amp-sub); cursor: pointer; font-size: 13px; padding: 0 2px; visibility: hidden; }
        #amp-panel .ly-line.has-edit .ly-undo { visibility: visible; }
        #amp-panel .ly-undo:hover { color: #fff; }
      </style>

      <div class="amp-section">
        <h4>Style</h4>
        <div class="amp-grid c3 ly-fonts">
          ${Object.entries(this.FONTS).map(([k, f]) => `<button class="amp-chip" data-font="${k}" style="${f.css ? `font-family:${f.css.replace(/"/g, "'")}` : ""}">${f.name}</button>`).join("")}
        </div>
        <div class="amp-row" style="margin-top:10px">
          <div class="amp-row-top"><span>Size</span><span class="ly-size-out"></span></div>
          <input type="range" class="ly-size" min="60" max="180" step="5">
        </div>
        <div class="ly-colors">
          <button class="amp-chip" data-color="theme">Theme</button>
          <button class="amp-chip" data-color="white">White</button>
          <button class="amp-chip" data-color="album">Album</button>
          <button class="amp-chip" data-color="custom">Custom</button>
          <input type="color" class="ly-custom">
        </div>
        <div class="amp-grid c2" style="margin-top:8px">
          <button class="amp-chip" data-align="left">Align left</button>
          <button class="amp-chip" data-align="center">Align center</button>
        </div>
        <label class="amp-toggle" style="margin-top:6px"><span>Glow</span><input type="checkbox" class="ly-glow"><i></i></label>
        <label class="amp-toggle"><span>ALL CAPS</span><input type="checkbox" class="ly-caps"><i></i></label>
        <label class="amp-toggle"><span>Restyle Spotify's lyrics screen</span><input type="checkbox" class="ly-spotify"><i></i></label>
      </div>

      <div class="amp-section">
        <h4>In the visualizer</h4>
        <div class="amp-grid c3">
          <button class="amp-chip" data-layer="off">Off</button>
          <button class="amp-chip" data-layer="behind">Behind visuals</button>
          <button class="amp-chip" data-layer="front">In front</button>
        </div>
        <div class="amp-row" style="margin-top:10px">
          <div class="amp-row-top"><span>Lyrics opacity</span><span class="ly-op-out"></span></div>
          <input type="range" class="ly-op" min="15" max="100" step="5">
        </div>
        <label class="amp-toggle"><span>Show translation there too</span><input type="checkbox" class="ly-viztrans"><i></i></label>
      </div>

      <div class="amp-section">
        <label class="amp-toggle"><span>Translate lyrics</span><input type="checkbox" class="ly-trans"><i></i></label>
        <select class="ly-sel ly-lang" style="margin-top:6px">
          ${this.LANGS.map(([k, n]) => `<option value="${k}">Translate to ${n}</option>`).join("")}
        </select>
      </div>

      <div class="amp-section">
        <div class="amp-big"><h4 style="margin:0">Lyrics</h4><button class="amp-chip ly-reset" style="padding:4px 8px;font-size:11px">Reset fixes</button></div>
        <div class="ly-status"></div>
        <div class="ly-list"></div>
        <div class="amp-hint">Click a line or translation to fix it (Enter saves, Esc cancels). Fixed lines show in yellow, and your fixes show everywhere: on Spotify's lyrics screen, in the visualizer, and next time you play the song. Click a time to jump there.</div>
      </div>`;

    const $ = (s) => root.querySelector(s);
    const list = $(".ly-list");
    const set = (patch) => { this.s.patch(patch); this.applyStyle(A); renderControls(); this.decorateSpotify(A, true); };

    const renderControls = () => {
      root.querySelectorAll("[data-font]").forEach((b) => b.classList.toggle("active", b.dataset.font === this.s.get("font")));
      root.querySelectorAll("[data-color]").forEach((b) => b.classList.toggle("active", b.dataset.color === this.s.get("color")));
      root.querySelectorAll("[data-align]").forEach((b) => b.classList.toggle("active", b.dataset.align === this.s.get("align")));
      root.querySelectorAll("[data-layer]").forEach((b) => b.classList.toggle("active", b.dataset.layer === this.s.get("layer")));
      A.ui.range($(".ly-size"), this.s.get("size"));
      $(".ly-size-out").textContent = this.s.get("size") + "%";
      A.ui.range($(".ly-op"), this.s.get("opacity"));
      $(".ly-op-out").textContent = this.s.get("opacity") + "%";
      $(".ly-custom").value = this.s.get("custom");
      $(".ly-glow").checked = this.s.get("glow");
      $(".ly-caps").checked = this.s.get("caps");
      $(".ly-spotify").checked = this.s.get("applySpotify");
      $(".ly-viztrans").checked = this.s.get("vizTrans");
      $(".ly-trans").checked = this.s.get("transOn");
      $(".ly-lang").value = this.s.get("lang");
    };

    root.querySelectorAll("[data-font]").forEach((b) => (b.onclick = () => set({ font: b.dataset.font })));
    root.querySelectorAll("[data-color]").forEach((b) => (b.onclick = () => set({ color: b.dataset.color })));
    root.querySelectorAll("[data-align]").forEach((b) => (b.onclick = () => set({ align: b.dataset.align })));
    root.querySelectorAll("[data-layer]").forEach((b) => (b.onclick = () => set({ layer: b.dataset.layer })));
    $(".ly-size").oninput = (e) => set({ size: +e.target.value });
    $(".ly-size").ondblclick = () => set({ size: 100 });
    $(".ly-op").oninput = (e) => set({ opacity: +e.target.value });
    $(".ly-custom").oninput = (e) => set({ custom: e.target.value, color: "custom" });
    $(".ly-glow").onchange = (e) => set({ glow: e.target.checked });
    $(".ly-caps").onchange = (e) => set({ caps: e.target.checked });
    $(".ly-spotify").onchange = (e) => set({ applySpotify: e.target.checked });
    $(".ly-viztrans").onchange = (e) => set({ vizTrans: e.target.checked });
    $(".ly-trans").onchange = (e) => { set({ transOn: e.target.checked }); this.translateCurrent(A); renderList(); };
    $(".ly-lang").onchange = (e) => { set({ lang: e.target.value }); this.translateCurrent(A); renderList(); };
    $(".ly-reset").onclick = () => {
      const edits = this.s.get("edits");
      delete edits[this.curId];
      this.s.set("edits", edits);
      A.emit("lyrics:changed");
      this.decorateSpotify(A, true);
    };
    A.on("theme", () => this.applyStyle(A));

    const fmt = (ms) => { const s = Math.floor(ms / 1000); return Math.floor(s / 60) + ":" + String(s % 60).padStart(2, "0"); };

    // Click-to-edit for a line or its translation
    const editable = (el, kind, i, current) => {
      el.onclick = () => {
        const inp = A.ui.el(`<input>`);
        inp.value = current;
        el.replaceWith(inp);
        inp.focus();
        inp.select();
        let done = false;
        const finish = (save) => {
          if (done) return;
          done = true;
          if (save) this.saveEdit(A, kind, i, inp.value.trim());
          else renderList();
        };
        inp.onkeydown = (e) => {
          e.stopPropagation();
          if (e.key === "Enter") finish(true);
          if (e.key === "Escape") finish(false);
        };
        inp.onblur = () => finish(true);
      };
    };

    const renderList = () => {
      $(".ly-status").textContent = this.status;
      const lines = this.lines();
      const trans = this.transLines();
      const ed = (this.s.get("edits")[this.curId] || {});
      $(".ly-reset").style.display = ed.lines && Object.keys(ed.lines).length || ed.trans && Object.keys(ed.trans).length ? "" : "none";
      list.innerHTML = "";
      lines.forEach((l, i) => {
        const trEdited = ed.trans && ed.trans[i] != null;
        const row = A.ui.el(`<div class="ly-line" data-i="${i}"><span class="ly-time"></span><div><div class="ly-txt"></div></div><button class="ly-undo" title="Undo fix">↺</button></div>`);
        row.querySelector(".ly-time").textContent = this.cache[this.curId].synced ? fmt(l.t) : "";
        row.querySelector(".ly-time").onclick = () => A.player.seek(l.t / 1000);
        const txt = row.querySelector(".ly-txt");
        txt.textContent = l.text || "♪";
        txt.classList.toggle("ly-edited", l.edited);
        editable(txt, "lines", i, l.text);
        if (trans && trans[i]) {
          const tr = A.ui.el(`<div class="ly-tr"></div>`);
          tr.textContent = trans[i];
          tr.classList.toggle("ly-edited", trEdited);
          row.children[1].appendChild(tr);
          editable(tr, "trans", i, trans[i]);
        }
        row.classList.toggle("has-edit", l.edited || trEdited);
        row.querySelector(".ly-undo").onclick = () => { this.saveEdit(A, "lines", i, null); this.saveEdit(A, "trans", i, null); };
        list.appendChild(row);
      });
    };

    // Highlight the line that's playing
    let lastNow = -1;
    setInterval(() => {
      if (!A.ui.isToolboxOpen || !A.ui.isToolboxOpen() || !root.classList.contains("active")) return;
      const c = this.cache[this.curId];
      if (!c || !c.synced) return;
      const i = this.indexAt(this.lines(), A.player.position());
      if (i === lastNow) return;
      lastNow = i;
      list.querySelectorAll(".ly-line.now").forEach((r) => r.classList.remove("now"));
      const row = list.querySelector(`.ly-line[data-i="${i}"]`);
      if (row) {
        row.classList.add("now");
        if (!list.contains(document.activeElement)) row.scrollIntoView({ block: "nearest" });
      }
    }, 200);

    A.on("lyrics:changed", renderList);
    renderControls();
    renderList();
  },
});
