// Mod: Equalizer. 10-band EQ, presets and a volume boost past 100%.

Amplify.register({
  id: "eq",
  name: "Equalizer",
  tabName: "EQ",
  description: "10-band equalizer with presets like Bass Boost and Vocal, plus a volume boost up to 300%.",
  needsEngine: true,
  icon: `<svg viewBox="0 0 24 24" width="18" height="18" fill="currentColor"><path d="M5 3a1 1 0 0 1 1 1v9.2a3 3 0 0 1 0 5.6V20a1 1 0 1 1-2 0v-1.2a3 3 0 0 1 0-5.6V4a1 1 0 0 1 1-1zm7 0a1 1 0 0 1 1 1v1.2a3 3 0 0 1 0 5.6V20a1 1 0 1 1-2 0v-9.2a3 3 0 0 1 0-5.6V4a1 1 0 0 1 1-1zm7 0a1 1 0 0 1 1 1v7.2a3 3 0 0 1 0 5.6V20a1 1 0 1 1-2 0v-3.2a3 3 0 0 1 0-5.6V4a1 1 0 0 1 1-1z"/></svg>`,

  BANDS: ["32", "64", "125", "250", "500", "1k", "2k", "4k", "8k", "16k"],
  PRESETS: {
    Flat:          { eq: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0] },
    "Bass Boost":  { eq: [8, 7, 5, 2, 0, 0, 0, 0, 0, 0] },
    "Bass Destroyer": { eq: [12, 11, 8, 3, -1, -2, 0, 0, 0, 0], volume: 120 },
    Vocal:         { eq: [-3, -2, -1, 1, 3, 4, 4, 2, 0, -1] },
    Treble:        { eq: [0, 0, 0, 0, 0, 1, 3, 5, 6, 7] },
    "Lo-fi":       { eq: [-6, -2, 2, 3, 2, 0, -3, -8, -12, -12] },
    Loud:          { eq: [4, 3, 2, 0, -1, 0, 2, 3, 3, 2], volume: 150 },
    Phone:         { eq: [-12, -12, -8, 0, 4, 6, 4, -6, -12, -12] },
  },

  audioDefaults: { eq: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0], volume: 100 },

  init(A) {
    this.s = A.store("eq", { ...this.audioDefaults, preset: "Flat" });
    A.audio.set("eq", { eq: this.s.get("eq"), volume: this.s.get("volume") });
  },

  push(A) {
    A.audio.set("eq", { eq: this.s.get("eq").slice(), volume: this.s.get("volume") });
  },

  mount(root, A) {
    root.innerHTML = `
      <style>
        #amp-panel .eq-bands { display: grid; grid-template-columns: repeat(10, 1fr); gap: 2px; margin: 4px 0 2px; }
        #amp-panel .eq-band { display: flex; flex-direction: column; align-items: center; gap: 4px; }
        #amp-panel .eq-band .eq-db { font-size: 9px; color: var(--amp-sub); font-variant-numeric: tabular-nums; height: 11px; }
        #amp-panel .eq-cell { position: relative; width: 24px; height: 120px; }
        #amp-panel .eq-cell input { position: absolute; width: 120px; left: 50%; top: 50%; transform: translate(-50%, -50%) rotate(-90deg); }
        #amp-panel .eq-cell::before { content: ""; position: absolute; left: 2px; right: 2px; top: 50%; height: 1px; background: rgba(255,255,255,.12); }
        #amp-panel .eq-band .eq-hz { font-size: 10px; color: var(--amp-sub); }
      </style>
      <div class="amp-section">
        <div class="amp-big"><h4 style="margin:0">Equalizer</h4><span class="eq-preset" style="color:var(--amp-sub);font-size:12px"></span></div>
        <div class="eq-bands">
          ${this.BANDS.map((b, i) => `
            <div class="eq-band">
              <span class="eq-db" data-db="${i}"></span>
              <div class="eq-cell"><input type="range" data-band="${i}" min="-12" max="12" step="1" data-bipolar></div>
              <span class="eq-hz">${b}</span>
            </div>`).join("")}
        </div>
      </div>
      <div class="amp-section">
        <h4>Presets</h4>
        <div class="amp-grid c4">
          ${Object.keys(this.PRESETS).map((p) => `<button class="amp-chip" data-preset="${p}">${p}</button>`).join("")}
        </div>
      </div>
      <div class="amp-section">
        <div class="amp-row">
          <div class="amp-row-top"><span>Volume boost</span><span class="eq-vol"></span></div>
          <input type="range" class="eq-volume" min="100" max="300" step="5">
        </div>
        <div class="amp-hint">Turn Spotify's own volume up first. A built-in limiter stops it from clipping, but high boosts squash the sound a bit. Double-click a slider to reset it.</div>
      </div>`;

    const bands = root.querySelectorAll("[data-band]");
    const presets = root.querySelectorAll("[data-preset]");
    const vol = root.querySelector(".eq-volume");
    const volOut = root.querySelector(".eq-vol");
    const presetOut = root.querySelector(".eq-preset");

    const render = () => {
      const eq = this.s.get("eq");
      bands.forEach((b) => {
        const v = eq[+b.dataset.band];
        A.ui.range(b, v);
        root.querySelector(`[data-db="${b.dataset.band}"]`).textContent = v > 0 ? "+" + v : v;
      });
      A.ui.range(vol, this.s.get("volume"));
      volOut.textContent = this.s.get("volume") + "%";
      const p = this.s.get("preset");
      presetOut.textContent = p || "Custom";
      presets.forEach((b) => b.classList.toggle("active", b.dataset.preset === p));
    };

    bands.forEach((b) => {
      const setBand = (v) => {
        const eq = this.s.get("eq").slice();
        eq[+b.dataset.band] = v;
        this.s.patch({ eq, preset: "" });
        this.push(A);
        render();
      };
      b.addEventListener("input", () => setBand(+b.value));
      b.addEventListener("dblclick", () => setBand(0));
    });
    vol.addEventListener("input", () => { this.s.set("volume", +vol.value); this.push(A); render(); });
    vol.addEventListener("dblclick", () => { this.s.set("volume", 100); this.push(A); render(); });
    presets.forEach((b) =>
      b.addEventListener("click", () => {
        const p = this.PRESETS[b.dataset.preset];
        this.s.patch({ eq: p.eq.slice(), volume: p.volume || 100, preset: b.dataset.preset });
        this.push(A);
        render();
      })
    );
    render();
  },
});
