// Mod: Skip Rules. Block songs/artists, skip intros, or auto-skip after X seconds.

Amplify.register({
  id: "skip",
  name: "Skip Rules",
  tabName: "Skip",
  description: "Auto-skip songs or artists you've blocked, skip the first few seconds of every song, or preview mode.",
  icon: `<svg viewBox="0 0 24 24" width="18" height="18" fill="currentColor"><path d="M5 5.3a1 1 0 0 1 1.5-.9l9 6.7a1.1 1.1 0 0 1 0 1.8l-9 6.7A1 1 0 0 1 5 18.7V5.3zM18 4a1 1 0 0 1 1 1v14a1 1 0 1 1-2 0V5a1 1 0 0 1 1-1z"/></svg>`,

  init(A) {
    this.s = A.store("skip", {
      songs: [],    // [{ title, artist }]
      artists: [],  // ["artist name"]
      intro: false, introSec: 10,
      preview: false, previewSec: 30,
      skipped: 0,
    });
    this.elapsed = 0;
    this.chain = 0; // auto-skips in a row (so a fully blocked playlist can't loop forever)
    this.lastAuto = 0;

    A.on("track", (m) => this.onTrack(A, m));

    // Count how long the current song has actually been playing
    setInterval(() => {
      if (!A.isEnabled("skip") || !A.player.isPlaying()) return;
      this.elapsed += 0.5;
      if (this.s.get("preview") && this.elapsed >= this.s.get("previewSec")) {
        this.elapsed = -9999; // only once per song
        this.autoSkip(A, "Preview time's up");
      }
      if (this.elapsed > 20) this.chain = 0;
    }, 500);
  },

  norm: (t) => (t || "").trim().toLowerCase(),
  artistsOf(m) { return (m.artist || "").split(/,\s*|\s+&\s+|\s+feat\.?\s+/i).map(this.norm).filter(Boolean); },

  blocked(m) {
    if (!m) return null;
    if (this.s.get("songs").some((s) => this.norm(s.title) === this.norm(m.title) && this.norm(s.artist) === this.norm(m.artist))) return "blocked song";
    const arts = this.artistsOf(m);
    if (this.s.get("artists").some((a) => arts.includes(this.norm(a)))) return "blocked artist";
    return null;
  },

  autoSkip(A, reason) {
    if (this.chain >= 15) { A.ui.toast("Amplify: too many skips in a row, pausing Skip Rules for this song"); return; }
    this.chain++;
    this.lastAuto = Date.now();
    this.s.set("skipped", this.s.get("skipped") + 1);
    A.ui.toast(`Skipped: ${reason}`);
    A.player.next();
    A.emit("skip:changed");
  },

  onTrack(A, m) {
    this.elapsed = 0;
    A.emit("skip:changed");
    if (!A.isEnabled("skip")) return;
    const why = this.blocked(m);
    if (why) return setTimeout(() => this.autoSkip(A, why), 250);
    if (this.s.get("intro")) {
      setTimeout(() => {
        if (A.player.current === m) {
          A.player.seek(this.s.get("introSec"));
          this.elapsed = 0;
        }
      }, 400);
    }
  },

  mount(root, A) {
    root.innerHTML = `
      <style>
        #amp-panel .sk-now { padding: 10px; border-radius: 10px; background: var(--amp-card); display: flex; gap: 10px; align-items: center; }
        #amp-panel .sk-now img { width: 40px; height: 40px; border-radius: 6px; object-fit: cover; background: #333; flex: none; }
        #amp-panel .sk-now div { min-width: 0; }
        #amp-panel .sk-now b, #amp-panel .sk-now span { display: block; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
        #amp-panel .sk-now span { color: var(--amp-sub); font-size: 12px; }
        #amp-panel .sk-list { max-height: 150px; overflow-y: auto; }
        #amp-panel .sk-item { display: flex; align-items: center; gap: 8px; padding: 5px 0; border-bottom: 1px solid rgba(255,255,255,.05); }
        #amp-panel .sk-item div { flex: 1; min-width: 0; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
        #amp-panel .sk-item small { color: var(--amp-sub); }
        #amp-panel .sk-item button { flex: none; border: none; background: none; color: var(--amp-sub); cursor: pointer; font-size: 16px; line-height: 1; padding: 2px 6px; border-radius: 4px; }
        #amp-panel .sk-item button:hover { color: #fff; background: rgba(255,255,255,.08); }
        #amp-panel .sk-empty { color: var(--amp-sub); font-size: 12px; padding: 4px 0; }
      </style>
      <div class="amp-section">
        <h4>Now playing</h4>
        <div class="sk-now"><img alt=""><div><b class="sk-title">Nothing playing</b><span class="sk-artist">Play a song to block it</span></div></div>
        <div class="amp-grid c3" style="margin-top:8px">
          <button class="amp-chip sk-block-song">Block song</button>
          <button class="amp-chip sk-block-artist">Block artist</button>
          <button class="amp-chip sk-skip">Skip now</button>
        </div>
      </div>
      <div class="amp-section">
        <label class="amp-toggle"><span>Skip intros</span><input type="checkbox" class="sk-intro"><i></i></label>
        <div class="amp-row">
          <div class="amp-row-top"><span>Start every song at</span><span class="sk-intro-out"></span></div>
          <input type="range" class="sk-intro-sec" min="3" max="60" step="1">
        </div>
        <label class="amp-toggle"><span>Preview mode</span><input type="checkbox" class="sk-preview"><i></i></label>
        <div class="amp-row">
          <div class="amp-row-top"><span>Skip each song after</span><span class="sk-preview-out"></span></div>
          <input type="range" class="sk-preview-sec" min="10" max="180" step="5">
        </div>
      </div>
      <div class="amp-section">
        <div class="amp-big"><h4 style="margin:0">Blocked</h4><span class="sk-count" style="color:var(--amp-sub);font-size:11px"></span></div>
        <div class="sk-list"></div>
      </div>`;

    const $ = (s) => root.querySelector(s);
    const list = $(".sk-list");

    const render = () => {
      const m = A.player.current;
      $(".sk-title").textContent = m ? m.title : "Nothing playing";
      $(".sk-artist").textContent = m ? m.artist : "Play a song to block it";
      const img = $(".sk-now img");
      if (m && m.art) img.src = m.art; else img.removeAttribute("src");
      const why = this.blocked(m);
      $(".sk-block-song").textContent = why === "blocked song" ? "Unblock song" : "Block song";

      $(".sk-intro").checked = this.s.get("intro");
      A.ui.range($(".sk-intro-sec"), this.s.get("introSec"));
      $(".sk-intro-out").textContent = "0:" + String(this.s.get("introSec")).padStart(2, "0");
      $(".sk-preview").checked = this.s.get("preview");
      A.ui.range($(".sk-preview-sec"), this.s.get("previewSec"));
      const ps = this.s.get("previewSec");
      $(".sk-preview-out").textContent = Math.floor(ps / 60) + ":" + String(ps % 60).padStart(2, "0");

      const songs = this.s.get("songs"), artists = this.s.get("artists");
      $(".sk-count").textContent = `${this.s.get("skipped")} auto-skipped`;
      list.innerHTML = "";
      if (!songs.length && !artists.length) list.innerHTML = `<div class="sk-empty">Nothing blocked yet.</div>`;
      artists.forEach((a, i) => {
        const row = A.ui.el(`<div class="sk-item"><div></div><button title="Unblock">×</button></div>`);
        row.firstChild.innerHTML = `<small>Artist · </small>`;
        row.firstChild.append(a);
        row.querySelector("button").onclick = () => { const x = artists.slice(); x.splice(i, 1); this.s.set("artists", x); render(); };
        list.appendChild(row);
      });
      songs.forEach((s, i) => {
        const row = A.ui.el(`<div class="sk-item"><div></div><button title="Unblock">×</button></div>`);
        row.firstChild.append(s.title);
        const sm = document.createElement("small");
        sm.textContent = " · " + s.artist;
        row.firstChild.appendChild(sm);
        row.querySelector("button").onclick = () => { const x = songs.slice(); x.splice(i, 1); this.s.set("songs", x); render(); };
        list.appendChild(row);
      });
    };

    $(".sk-block-song").onclick = () => {
      const m = A.player.current;
      if (!m) return;
      const songs = this.s.get("songs");
      const idx = songs.findIndex((s) => this.norm(s.title) === this.norm(m.title) && this.norm(s.artist) === this.norm(m.artist));
      if (idx >= 0) { songs.splice(idx, 1); this.s.set("songs", songs); render(); return; }
      this.s.set("songs", [...songs, { title: m.title, artist: m.artist }]);
      render();
      if (A.isEnabled("skip")) this.autoSkip(A, "blocked song");
    };
    $(".sk-block-artist").onclick = () => {
      const m = A.player.current;
      if (!m || !m.artist) return;
      const main = m.artist.split(/,\s*|\s+&\s+/)[0].trim();
      if (!this.s.get("artists").some((a) => this.norm(a) === this.norm(main))) this.s.set("artists", [...this.s.get("artists"), main]);
      render();
      if (A.isEnabled("skip")) this.autoSkip(A, "blocked artist");
    };
    $(".sk-skip").onclick = () => A.player.next();
    $(".sk-intro").onchange = (e) => { this.s.set("intro", e.target.checked); render(); };
    $(".sk-preview").onchange = (e) => { this.s.set("preview", e.target.checked); this.elapsed = 0; render(); };
    $(".sk-intro-sec").oninput = (e) => { this.s.set("introSec", +e.target.value); render(); };
    $(".sk-preview-sec").oninput = (e) => { this.s.set("previewSec", +e.target.value); render(); };

    A.on("track", render);
    A.on("skip:changed", render);
    render();
  },
});
