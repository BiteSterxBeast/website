// Mod: Speed. Speed up or slow down songs, with or without changing pitch.
// Also lets you give individual songs their own speed (set from the Speed tab
// or from the ⚡ button on each row of a playlist/album).

Amplify.register({
  id: "speed",
  name: "Speed",
  description: "Speed up or slow down songs, type any speed, edit the presets, and give individual songs their own speed.",
  icon: `<svg viewBox="0 0 24 24" width="18" height="18" fill="currentColor"><path d="M12 4a10 10 0 0 0-10 10c0 2.7 1.1 5.2 2.9 7l1.4-1.4A8 8 0 1 1 20 14a8 8 0 0 1-2.3 5.6l1.4 1.4A10 10 0 0 0 12 4z"/><path d="m16.6 8.3-3.4 4.4a2 2 0 1 1-1.4-1.4l4.4-3.4.4.4z"/></svg>`,

  MIN: 0.5,        // slider range
  MAX: 2.0,
  TYPE_MIN: 0.25,  // range you can type in
  TYPE_MAX: 4.0,
  STEP: 0.05,
  DEFAULT_PRESETS: [0.75, 0.85, 1, 1.25, 1.5],

  init(A) {
    this.s = A.store("speed", {
      rate: 1,              // your normal speed
      keepPitch: false,
      presets: this.DEFAULT_PRESETS.slice(),
      perSong: true,
      songs: {},            // key -> { title, artist, rate }
    });
    this.active = null;     // key of the song rule playing right now (null = normal speed)
    this.applying = false;

    A.media.set(this.s.get("rate"), this.s.get("keepPitch"));

    // Remember whatever speed gets set: on the song's rule if one is playing, otherwise as your normal speed
    A.on("speed", ({ rate, keepPitch }) => {
      if (!A.isEnabled("speed") || this.applying) return;
      this.s.set("keepPitch", keepPitch);
      if (this.active && this.s.get("songs")[this.active]) {
        const songs = this.s.get("songs");
        songs[this.active].rate = rate;
        this.s.set("songs", songs);
        A.emit("songspeeds");
      } else {
        this.s.set("rate", rate);
      }
    });

    A.on("track", (m) => this.applyForTrack(A, m));

    // Alt+Up / Alt+Down / Alt+0
    document.addEventListener("keydown", (e) => {
      if (!e.altKey || !A.isEnabled("speed")) return;
      const r = A.media.rate;
      if (e.key === "ArrowUp") this.setRate(A, r + this.STEP, true);
      else if (e.key === "ArrowDown") this.setRate(A, r - this.STEP, true);
      else if (e.key === "0") this.setRate(A, 1);
      else return;
      e.preventDefault();
      A.ui.toast(`Speed ${A.media.rate.toFixed(2)}x`);
    }, true);

    this.initRows(A);
  },

  enable(A) { this.applyForTrack(A, A.player.current, true); },
  disable(A) { this.active = null; this.applyRate(A, 1, true); },

  // ---------- Speed helpers ----------
  clamp(v) { return Math.min(this.TYPE_MAX, Math.max(this.TYPE_MIN, Math.round(v * 100) / 100)); },

  // User-chosen speed (slider, presets, typing, shortcuts)
  setRate(A, v, snap = false) {
    let r = snap ? Math.round(v / this.STEP) * this.STEP : v;
    A.media.set(this.clamp(r));
  },

  // Speed set by Amplify itself (switching songs) without overwriting your normal speed
  applyRate(A, rate, keepPitch) {
    this.applying = true;
    A.media.set(rate, keepPitch);
    this.applying = false;
  },

  // ---------- Per-song speeds ----------
  norm: (t) => (t || "").toLowerCase().replace(/\s+/g, " ").trim(),
  keyOf(title, artist) { return this.norm(title) + "|" + this.norm(artist); },

  // Find a saved rule for a song (artist only has to match the start, since Spotify
  // sometimes lists features after the main artist)
  findRule(m) {
    if (!m || !m.title) return null;
    const t = this.norm(m.title), a = this.norm(m.artist);
    const songs = this.s.get("songs");
    for (const k in songs) {
      const r = songs[k];
      if (this.norm(r.title) === t && (!r.artist || a.startsWith(this.norm(r.artist)))) return k;
    }
    return null;
  },

  applyForTrack(A, m, force = false) {
    if (!A.isEnabled("speed")) return;
    const key = this.s.get("perSong") ? this.findRule(m) : null;
    const prev = this.active;
    this.active = key;
    if (key) {
      const rate = this.s.get("songs")[key].rate;
      if (force || Math.abs(A.media.rate - rate) > 0.001) {
        this.applyRate(A, rate, this.s.get("keepPitch"));
        A.ui.toast(`Song speed ${rate.toFixed(2)}x`);
      }
    } else if (prev || force) {
      this.applyRate(A, this.s.get("rate"), this.s.get("keepPitch"));
    }
    A.emit("songspeeds");
  },

  // Artist as Spotify shows it in the player bar (first artist link), so it matches playlist rows
  currentArtist(m) {
    const el = document.querySelector('[data-testid="context-item-info-artist"]');
    return (el && el.textContent.trim()) || (m && m.artist ? m.artist.split(/,\s*/)[0] : "");
  },

  setSongRate(A, title, artist, rate) {
    const songs = this.s.get("songs");
    const key = this.keyOf(title, artist);
    // remove any older rule for the same song
    for (const k in songs) {
      if (this.norm(songs[k].title) === this.norm(title) && this.norm(songs[k].artist) === this.norm(artist)) delete songs[k];
    }
    if (rate != null) songs[key] = { title, artist, rate: this.clamp(rate) };
    this.s.set("songs", songs);
    this.applyForTrack(A, A.player.current, true);
  },

  // ---------- ⚡ speed button on every track row ----------
  initRows(A) {
    const ready = () => {
      const css = document.createElement("style");
      css.textContent = `
        .amp-row-speed {
          display: inline-flex; align-items: center; gap: 3px; margin-right: 16px; padding: 3px 9px;
          border: none; border-radius: 999px; background: transparent; cursor: pointer;
          color: #b3b3b3; font-family: inherit; font-size: 12px; font-weight: 700; font-variant-numeric: tabular-nums;
          opacity: 0; transition: opacity .12s, background .12s, color .12s;
        }
        [data-testid="tracklist-row"]:hover .amp-row-speed, [role="row"]:hover .amp-row-speed, .amp-row-speed:focus { opacity: 1; }
        .amp-row-speed:hover { color: #fff; background: rgba(255,255,255,.1); }
        .amp-row-speed.set { opacity: 1; color: var(--amp-on-accent); background: var(--amp-accent); }
        .amp-row-speed.set:hover { filter: brightness(1.1); }

        #amp-song-pop {
          position: fixed; z-index: 100000; width: 250px; padding: 14px; border-radius: 10px;
          background: #282828; color: #fff; box-shadow: 0 16px 32px rgba(0,0,0,.6); font-family: inherit; font-size: 13px;
          display: none;
        }
        #amp-song-pop.open { display: block; }
        #amp-song-pop * { box-sizing: border-box; }
        #amp-song-pop .sp-pop-title { font-weight: 800; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
        #amp-song-pop .sp-pop-artist { color: #a7a7a7; font-size: 12px; margin-bottom: 10px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
        #amp-song-pop .sp-pop-row { display: flex; gap: 6px; align-items: center; margin-bottom: 8px; }
        #amp-song-pop input {
          flex: 1; min-width: 0; padding: 7px 10px; border-radius: 6px; border: 1px solid #444; background: #1f1f1f;
          color: #fff; font: inherit; font-weight: 700; outline: none;
        }
        #amp-song-pop input:focus { border-color: var(--amp-accent); }
        #amp-song-pop button {
          padding: 7px 8px; border: none; border-radius: 6px; cursor: pointer; background: #3a3a3a; color: #fff;
          font: inherit; font-size: 12px; font-weight: 600;
        }
        #amp-song-pop button:hover { background: #4a4a4a; }
        #amp-song-pop button.active, #amp-song-pop .sp-pop-save { background: var(--amp-accent); color: var(--amp-on-accent); }
        #amp-song-pop .sp-pop-chips { display: grid; grid-template-columns: repeat(5, 1fr); gap: 5px; margin-bottom: 8px; }
        #amp-song-pop .sp-pop-default { width: 100%; }
      `;
      document.head.appendChild(css);

      this.pop = A.ui.el(`
        <div id="amp-song-pop">
          <div class="sp-pop-title"></div>
          <div class="sp-pop-artist"></div>
          <div class="sp-pop-chips"></div>
          <div class="sp-pop-row"><input class="sp-pop-input" inputmode="decimal" placeholder="Type a speed, e.g. 0.8"><button class="sp-pop-save">Set</button></div>
          <button class="sp-pop-default">Use normal speed</button>
        </div>`);
      document.body.appendChild(this.pop);
      document.addEventListener("mousedown", (e) => {
        if (this.pop.classList.contains("open") && !this.pop.contains(e.target) && !e.target.closest(".amp-row-speed")) {
          this.pop.classList.remove("open");
        }
      });

      let queued = false;
      const scan = () => { queued = false; this.decorateRows(A); };
      new MutationObserver(() => { if (!queued) { queued = true; requestAnimationFrame(scan); } })
        .observe(document.body, { childList: true, subtree: true });
      A.on("songspeeds", () => this.decorateRows(A));
      A.on("mods", () => this.decorateRows(A));
      this.decorateRows(A);
    };
    if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", ready);
    else ready();
  },

  rowInfo(row) {
    const link = row.querySelector('[data-testid="internal-track-link"]') || row.querySelector('a[href*="/track/"]');
    const title = link ? link.textContent.trim() : "";
    const artistLink = row.querySelector('a[href*="/artist/"]');
    let artist = artistLink ? artistLink.textContent.trim() : "";
    // Album pages don't link the artist on every row; fall back to the row's subtitle text
    if (!artist && link) {
      const sub = link.parentElement && link.parentElement.nextElementSibling;
      artist = sub ? sub.textContent.replace(/^E\s*/, "").split(",")[0].trim() : "";
    }
    return { title, artist };
  },

  decorateRows(A) {
    const on = A.isEnabled("speed") && this.s.get("perSong");
    const rows = document.querySelectorAll('[data-testid="tracklist-row"]');
    rows.forEach((row) => {
      let btn = row.querySelector(".amp-row-speed");
      if (!on) { if (btn) btn.remove(); return; }
      const info = this.rowInfo(row);
      if (!info.title) return;
      if (!btn) {
        // Last column holds the "added" check + duration; our button goes just before them
        const cells = row.querySelectorAll('[role="gridcell"]');
        const cell = cells[cells.length - 1];
        if (!cell) return;
        btn = A.ui.el(`<button class="amp-row-speed" title="Speed for this song"></button>`);
        btn.addEventListener("click", (e) => {
          e.stopPropagation();
          e.preventDefault();
          this.openPop(A, btn);
        });
        btn.addEventListener("dblclick", (e) => e.stopPropagation()); // don't start playback
        cell.insertBefore(btn, cell.firstChild);
      }
      // Rows get recycled while scrolling, so always refresh the song this button points at
      btn.dataset.title = info.title;
      btn.dataset.artist = info.artist;
      const key = this.findRule({ title: info.title, artist: info.artist });
      const rate = key ? this.s.get("songs")[key].rate : null;
      const label = rate != null ? `⚡ ${rate.toFixed(2).replace(/0$/, "")}x` : "⚡";
      if (btn.textContent !== label) btn.textContent = label;
      btn.classList.toggle("set", rate != null);
    });
  },

  openPop(A, btn) {
    const title = btn.dataset.title, artist = btn.dataset.artist;
    const pop = this.pop;
    const key = this.findRule({ title, artist });
    const current = key ? this.s.get("songs")[key].rate : null;

    pop.querySelector(".sp-pop-title").textContent = title;
    pop.querySelector(".sp-pop-artist").textContent = artist;
    const chips = pop.querySelector(".sp-pop-chips");
    chips.innerHTML = "";
    this.s.get("presets").forEach((v) => {
      const c = A.ui.el(`<button>${v === 1 ? "1x" : v}</button>`);
      c.classList.toggle("active", current != null && Math.abs(current - v) < 0.001);
      c.onclick = () => { this.setSongRate(A, title, artist, v); pop.classList.remove("open"); };
      chips.appendChild(c);
    });
    const input = pop.querySelector(".sp-pop-input");
    input.value = current != null ? current : "";
    const save = () => {
      const v = parseFloat(input.value.replace(",", ".").replace(/x/i, ""));
      if (!isFinite(v)) return input.focus();
      this.setSongRate(A, title, artist, v);
      pop.classList.remove("open");
    };
    pop.querySelector(".sp-pop-save").onclick = save;
    input.onkeydown = (e) => { if (e.key === "Enter") save(); e.stopPropagation(); };
    const def = pop.querySelector(".sp-pop-default");
    def.style.display = current != null ? "" : "none";
    def.onclick = () => { this.setSongRate(A, title, artist, null); pop.classList.remove("open"); };

    pop.classList.add("open");
    const r = btn.getBoundingClientRect();
    const h = pop.offsetHeight;
    pop.style.left = Math.min(window.innerWidth - 266, Math.max(8, r.right - 250)) + "px";
    pop.style.top = (r.bottom + 6 + h > window.innerHeight ? r.top - h - 6 : r.bottom + 6) + "px";
    input.focus();
    input.select();
  },

  // ---------- Speed tab ----------
  mount(root, A) {
    root.innerHTML = `
      <style>
        #amp-panel .sp-head { display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px; }
        #amp-panel .sp-val {
          width: 104px; padding: 2px 6px; border: 1px solid transparent; border-radius: 6px; background: transparent;
          color: var(--amp-text); font-family: inherit; font-size: 24px; font-weight: 800; text-align: right;
          font-variant-numeric: tabular-nums; outline: none; cursor: text;
        }
        #amp-panel .sp-val:hover { border-color: #3e3e3e; }
        #amp-panel .sp-val:focus { border-color: var(--amp-accent); background: #2a2a2a; }
        #amp-panel .sp-banner {
          display: none; align-items: center; justify-content: space-between; gap: 8px; margin-bottom: 10px;
          padding: 7px 10px; border-radius: 8px; background: color-mix(in srgb, var(--amp-accent) 18%, transparent);
          font-size: 12px; color: var(--amp-text);
        }
        #amp-panel .sp-banner.show { display: flex; }
        #amp-panel .sp-banner button { flex: none; border: none; background: none; color: var(--amp-accent); font: inherit; font-weight: 700; cursor: pointer; padding: 0; }
        #amp-panel .sp-presets-head { display: flex; justify-content: space-between; align-items: center; margin-top: 12px; margin-bottom: 6px; }
        #amp-panel .sp-presets-head span { color: var(--amp-sub); font-size: 11px; }
        #amp-panel .sp-link { border: none; background: none; color: var(--amp-sub); font: inherit; font-size: 11px; font-weight: 700; cursor: pointer; padding: 0; }
        #amp-panel .sp-link:hover { color: var(--amp-text); }
        #amp-panel .sp-edit input {
          width: 100%; padding: 6px 2px; border-radius: 7px; border: 1px solid #444; background: #2a2a2a;
          color: #fff; font-family: inherit; font-size: 12px; font-weight: 700; text-align: center; outline: none;
        }
        #amp-panel .sp-edit input:focus { border-color: var(--amp-accent); }
        #amp-panel .sp-song { display: flex; align-items: center; gap: 8px; padding: 6px 0; border-bottom: 1px solid rgba(255,255,255,.05); }
        #amp-panel .sp-song div { flex: 1; min-width: 0; }
        #amp-panel .sp-song b, #amp-panel .sp-song small { display: block; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
        #amp-panel .sp-song b { font-size: 12px; font-weight: 600; }
        #amp-panel .sp-song small { color: var(--amp-sub); font-size: 11px; }
        #amp-panel .sp-song input {
          width: 54px; padding: 4px 6px; border-radius: 6px; border: 1px solid #444; background: #2a2a2a; color: #fff;
          font-family: inherit; font-size: 12px; font-weight: 700; text-align: center; outline: none;
        }
        #amp-panel .sp-song input:focus { border-color: var(--amp-accent); }
        #amp-panel .sp-song button { flex: none; border: none; background: none; color: var(--amp-sub); cursor: pointer; font-size: 16px; padding: 2px 6px; border-radius: 4px; }
        #amp-panel .sp-song button:hover { color: #fff; background: rgba(255,255,255,.08); }
        #amp-panel .sp-list { max-height: 170px; overflow-y: auto; }
        #amp-panel .sp-empty { color: var(--amp-sub); font-size: 12px; padding: 4px 0; line-height: 1.45; }
      </style>

      <div class="amp-section">
        <div class="sp-banner"><span>⚡ Custom speed for <b class="sp-banner-song"></b></span><button class="sp-use-default">Use normal</button></div>
        <div class="sp-head"><h4 style="margin:0">Playback speed</h4><input class="sp-val" inputmode="decimal" title="Click to type a speed (0.25x to 4x)"></div>
        <input type="range" class="sp-slider" min="${this.MIN}" max="${this.MAX}" step="${this.STEP}">
        <div class="amp-scale"><span>0.5x</span><span>1x</span><span>2x</span></div>
        <div class="sp-presets-head"><span>Presets</span><button class="sp-link sp-edit-btn">Edit</button></div>
        <div class="amp-grid c5 sp-presets"></div>
      </div>

      <div class="amp-section">
        <label class="amp-toggle"><span>Per-song speeds</span><input type="checkbox" class="sp-persong"><i></i></label>
        <div class="amp-grid c2" style="margin:8px 0 10px">
          <button class="amp-chip sp-save-song">Save for this song</button>
          <button class="amp-chip sp-remove-song">Remove song speed</button>
        </div>
        <div class="sp-list"></div>
      </div>

      <div class="amp-section">
        <label class="amp-toggle"><span>Keep original pitch</span><input type="checkbox" class="sp-pitch"><i></i></label>
        <div class="amp-hint">Off: slower songs sound deeper and faster songs sound higher (the slowed / nightcore sound). On: only the tempo changes.</div>
        <div class="amp-hint">Double-click the slider to reset · Alt+↑ / Alt+↓ to adjust · Alt+0 to reset</div>
      </div>`;

    const $ = (s) => root.querySelector(s);
    const slider = $(".sp-slider");
    const val = $(".sp-val");
    const pitch = $(".sp-pitch");
    const presetsEl = $(".sp-presets");
    const editBtn = $(".sp-edit-btn");
    const list = $(".sp-list");
    let editing = false;

    // Presets: normal chips, or number boxes while editing
    const renderPresets = () => {
      presetsEl.innerHTML = "";
      presetsEl.classList.toggle("sp-edit", editing);
      editBtn.textContent = editing ? "Done" : "Edit";
      this.s.get("presets").forEach((v, i) => {
        if (editing) {
          const inp = A.ui.el(`<input inputmode="decimal" value="${v}">`);
          inp.addEventListener("keydown", (e) => { e.stopPropagation(); if (e.key === "Enter") inp.blur(); });
          inp.addEventListener("change", () => {
            const n = parseFloat(inp.value.replace(",", ".").replace(/x/i, ""));
            const presets = this.s.get("presets").slice();
            presets[i] = isFinite(n) ? this.clamp(n) : presets[i];
            this.s.set("presets", presets);
            inp.value = presets[i];
          });
          presetsEl.appendChild(inp);
        } else {
          const c = A.ui.el(`<button class="amp-chip">${v === 1 ? "1x" : v}</button>`);
          c.classList.toggle("active", Math.abs(v - A.media.rate) < 0.001);
          c.onclick = () => this.setRate(A, v);
          presetsEl.appendChild(c);
        }
      });
      if (editing) {
        const reset = A.ui.el(`<button class="sp-link" style="grid-column:1/-1;justify-self:start;margin-top:2px">Reset presets</button>`);
        reset.onclick = () => { this.s.set("presets", this.DEFAULT_PRESETS.slice()); renderPresets(); A.emit("songspeeds"); };
        presetsEl.appendChild(reset);
      }
    };
    editBtn.onclick = () => { editing = !editing; renderPresets(); A.emit("songspeeds"); };

    const renderSongs = () => {
      const m = A.player.current;
      const songs = this.s.get("songs");
      const keys = Object.keys(songs);
      $(".sp-persong").checked = this.s.get("perSong");
      $(".sp-save-song").disabled = !m;
      $(".sp-remove-song").style.display = this.active ? "" : "none";
      $(".sp-save-song").textContent = this.active ? "Update song speed" : "Save for this song";

      const banner = $(".sp-banner");
      banner.classList.toggle("show", !!this.active);
      if (this.active && songs[this.active]) $(".sp-banner-song").textContent = songs[this.active].title;

      list.innerHTML = "";
      if (!keys.length) {
        list.innerHTML = `<div class="sp-empty">No songs yet. Hover a song in any playlist and click its ⚡ button, or play a song and click “Save for this song”.</div>`;
        return;
      }
      keys.forEach((k) => {
        const r = songs[k];
        const row = A.ui.el(`<div class="sp-song"><div><b></b><small></small></div><input inputmode="decimal"><button title="Remove">×</button></div>`);
        row.querySelector("b").textContent = r.title;
        row.querySelector("small").textContent = r.artist;
        const inp = row.querySelector("input");
        inp.value = r.rate;
        inp.addEventListener("keydown", (e) => { e.stopPropagation(); if (e.key === "Enter") inp.blur(); });
        inp.addEventListener("change", () => {
          const n = parseFloat(inp.value.replace(",", ".").replace(/x/i, ""));
          if (isFinite(n)) this.setSongRate(A, r.title, r.artist, n);
          else inp.value = r.rate;
        });
        row.querySelector("button").onclick = () => this.setSongRate(A, r.title, r.artist, null);
        list.appendChild(row);
      });
    };

    const render = () => {
      A.ui.range(slider, Math.min(this.MAX, Math.max(this.MIN, A.media.rate)));
      if (document.activeElement !== val) val.value = A.media.rate.toFixed(2) + "x";
      pitch.checked = A.media.keepPitch;
      if (!editing) presetsEl.querySelectorAll(".amp-chip").forEach((c, i) =>
        c.classList.toggle("active", Math.abs(this.s.get("presets")[i] - A.media.rate) < 0.001));
      renderSongs();
    };

    // Typing a speed: click the number, type e.g. 0.8 or 1.37, press Enter
    const commitTyped = () => {
      const n = parseFloat(val.value.replace(",", ".").replace(/x/i, ""));
      if (isFinite(n)) this.setRate(A, n);
      val.value = A.media.rate.toFixed(2) + "x";
    };
    val.addEventListener("focus", () => { val.value = String(A.media.rate); val.select(); });
    val.addEventListener("keydown", (e) => {
      e.stopPropagation(); // don't trigger Spotify's keyboard shortcuts while typing
      if (e.key === "Enter") { commitTyped(); val.blur(); }
      if (e.key === "Escape") { val.value = A.media.rate.toFixed(2) + "x"; val.blur(); }
    });
    val.addEventListener("blur", commitTyped);

    slider.addEventListener("input", () => this.setRate(A, +slider.value, true));
    slider.addEventListener("dblclick", () => this.setRate(A, 1));
    pitch.addEventListener("change", () => A.media.set(A.media.rate, pitch.checked));

    $(".sp-persong").onchange = (e) => { this.s.set("perSong", e.target.checked); this.applyForTrack(A, A.player.current, true); };
    $(".sp-save-song").onclick = () => {
      const m = A.player.current;
      if (!m) return;
      const rate = A.media.rate;
      this.setSongRate(A, m.title, this.currentArtist(m), rate);
      A.ui.toast(`Saved ${rate.toFixed(2)}x for ${m.title}`);
    };
    $(".sp-remove-song").onclick = () => {
      const r = this.s.get("songs")[this.active];
      if (r) this.setSongRate(A, r.title, r.artist, null);
    };
    $(".sp-use-default").onclick = () => $(".sp-remove-song").click();

    A.on("speed", render);
    A.on("songspeeds", render);
    A.on("track", render);
    renderPresets();
    render();
  },
});
