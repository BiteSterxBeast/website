// Mod: Themes. Recolor Spotify's accent color and background.

Amplify.register({
  id: "themes",
  name: "Themes",
  tabName: "Theme",
  description: "Recolor Spotify: pick an accent color (play button, sliders, highlights) and a background.",
  icon: `<svg viewBox="0 0 24 24" width="18" height="18" fill="currentColor"><path d="M12 2a10 10 0 0 0 0 20c1.1 0 2-.9 2-2 0-.5-.2-1-.5-1.3-.3-.4-.5-.8-.5-1.3 0-1.1.9-2 2-2h2.4A4.6 4.6 0 0 0 22 10.8C22 5.9 17.5 2 12 2zM6.5 13a1.5 1.5 0 1 1 0-3 1.5 1.5 0 0 1 0 3zm3-4a1.5 1.5 0 1 1 0-3 1.5 1.5 0 0 1 0 3zm5 0a1.5 1.5 0 1 1 0-3 1.5 1.5 0 0 1 0 3zm3 4a1.5 1.5 0 1 1 0-3 1.5 1.5 0 0 1 0 3z"/></svg>`,

  ACCENTS: {
    "Spotify Green": "#1ed760",
    "Red Lightning": "#ff2b2b",
    Purple: "#a855f7",
    Ocean: "#22a6f2",
    Pink: "#ff4fa3",
    Gold: "#ffc531",
    Orange: "#ff7a1a",
    Mint: "#3ff0c0",
  },
  BACKGROUNDS: {
    Default: null,
    "Pitch Black": { base: "#000000", hi: "#121212", top: "#000000" },
    "Red Night": { base: "#140707", hi: "#241010", top: "#0a0303" },
    Midnight: { base: "#080d1a", hi: "#121a2e", top: "#04060d" },
    Grape: { base: "#120a1c", hi: "#1f1430", top: "#09050f" },
  },

  init(A) {
    this.s = A.store("themes", { accent: "#1ed760", bg: "Default", spotify: true });
    this.styleEl = null;
    if (document.documentElement) this.apply(A);
    else document.addEventListener("DOMContentLoaded", () => this.apply(A), { once: true });
  },

  enable(A) { this.apply(A); },
  disable() { this.clear(); },

  clear() {
    document.documentElement.style.removeProperty("--amp-accent");
    document.documentElement.style.removeProperty("--amp-on-accent");
    if (this.styleEl) this.styleEl.textContent = "";
  },

  // Lighten (amt > 0) or darken (amt < 0) a hex color
  shade(hex, amt) {
    const n = parseInt(hex.slice(1), 16);
    const ch = (v) => Math.round(Math.min(255, Math.max(0, amt > 0 ? v + (255 - v) * amt : v * (1 + amt))));
    const r = ch(n >> 16), g = ch((n >> 8) & 255), b = ch(n & 255);
    return "#" + ((1 << 24) | (r << 16) | (g << 8) | b).toString(16).slice(1);
  },
  textOn(hex) {
    const n = parseInt(hex.slice(1), 16);
    const lum = (0.299 * (n >> 16) + 0.587 * ((n >> 8) & 255) + 0.114 * (n & 255)) / 255;
    return lum > 0.6 ? "#000000" : "#ffffff";
  },

  apply(A) {
    if (!A.isEnabled("themes")) return this.clear();
    const accent = this.s.get("accent");
    const on = this.textOn(accent);
    const root = document.documentElement;
    root.style.setProperty("--amp-accent", accent);
    root.style.setProperty("--amp-on-accent", on);

    if (!this.styleEl) {
      this.styleEl = document.createElement("style");
      this.styleEl.id = "amp-theme";
      (document.head || document.documentElement).appendChild(this.styleEl);
    }
    if (!this.s.get("spotify")) { this.styleEl.textContent = ""; return; }

    let css = "";
    if (accent.toLowerCase() !== "#1ed760") {
      css += `
        html body .encore-dark-theme, html body .encore-dark-theme .encore-base-set {
          --text-bright-accent: ${accent} !important;
          --essential-bright-accent: ${accent} !important;
          --decorative-subdued-accent: ${this.shade(accent, -0.5)} !important;
        }
        html body .encore-dark-theme .encore-bright-accent-set {
          --background-base: ${accent} !important;
          --background-highlight: ${this.shade(accent, 0.15)} !important;
          --background-press: ${this.shade(accent, -0.2)} !important;
          --text-base: ${on} !important;
          --essential-base: ${on} !important;
        }
        ::selection { background: ${accent}; color: ${on}; }`;
    }
    const bg = this.BACKGROUNDS[this.s.get("bg")];
    if (bg) {
      css += `
        html body .encore-dark-theme, html body .encore-dark-theme .encore-base-set {
          --background-base: ${bg.base} !important;
          --background-highlight: ${bg.hi} !important;
          --background-elevated-base: ${bg.hi} !important;
          --background-tinted-base: ${bg.hi} !important;
        }
        html body, html body .Root__top-container { background-color: ${bg.top} !important; }`;
    }
    this.styleEl.textContent = css;
  },

  mount(root, A) {
    root.innerHTML = `
      <style>
        #amp-panel .th-swatches { display: grid; grid-template-columns: repeat(4, 1fr); gap: 8px; }
        #amp-panel .th-sw {
          display: flex; flex-direction: column; align-items: center; gap: 5px; padding: 8px 2px;
          border: 2px solid transparent; border-radius: 10px; background: var(--amp-card); cursor: pointer;
          color: var(--amp-sub); font-family: inherit; font-size: 10px; font-weight: 600;
        }
        #amp-panel .th-sw i { width: 22px; height: 22px; border-radius: 50%; box-shadow: 0 0 0 2px rgba(0,0,0,.3) inset; }
        #amp-panel .th-sw.active { border-color: #fff; color: #fff; }
        #amp-panel .th-custom { display: flex; align-items: center; justify-content: space-between; margin-top: 10px; color: #e0e0e0; }
        #amp-panel .th-custom input[type=color] { width: 44px; height: 26px; border: none; border-radius: 6px; padding: 0; background: none; cursor: pointer; }
        #amp-panel .th-bgs { display: grid; grid-template-columns: repeat(5, 1fr); gap: 6px; }
        #amp-panel .th-bg {
          height: 46px; border-radius: 8px; border: 2px solid transparent; cursor: pointer;
          display: flex; align-items: flex-end; justify-content: center; padding-bottom: 4px;
          color: #ddd; font-family: inherit; font-size: 9px; font-weight: 600; line-height: 1.1; text-align: center;
        }
        #amp-panel .th-bg.active { border-color: #fff; }
      </style>
      <div class="amp-section">
        <h4>Accent color</h4>
        <div class="th-swatches">
          ${Object.entries(this.ACCENTS).map(([n, c]) => `<button class="th-sw" data-accent="${c}" title="${n}"><i style="background:${c}"></i>${n.replace("Spotify ", "")}</button>`).join("")}
        </div>
        <label class="th-custom"><span>Custom color</span><input type="color" class="th-color"></label>
      </div>
      <div class="amp-section">
        <h4>Background</h4>
        <div class="th-bgs">
          ${Object.entries(this.BACKGROUNDS).map(([n, b]) => `<button class="th-bg" data-bg="${n}" style="background:${b ? `linear-gradient(160deg, ${b.hi}, ${b.top})` : "linear-gradient(160deg,#2a2a2a,#121212)"}">${n}</button>`).join("")}
        </div>
      </div>
      <div class="amp-section">
        <label class="amp-toggle"><span>Recolor Spotify too</span><input type="checkbox" class="th-spotify"><i></i></label>
        <div class="amp-hint">Off: only Amplify's own panel and visualizer change color. Spotify sometimes renames its styles, so if part of the page stops recoloring after an update, that's why.</div>
      </div>`;

    const swatches = root.querySelectorAll("[data-accent]");
    const bgs = root.querySelectorAll("[data-bg]");
    const color = root.querySelector(".th-color");
    const spotify = root.querySelector(".th-spotify");

    const render = () => {
      const a = this.s.get("accent").toLowerCase();
      swatches.forEach((s) => s.classList.toggle("active", s.dataset.accent.toLowerCase() === a));
      bgs.forEach((b) => b.classList.toggle("active", b.dataset.bg === this.s.get("bg")));
      color.value = a;
      spotify.checked = this.s.get("spotify");
    };
    const update = (patch) => { this.s.patch(patch); this.apply(A); render(); A.emit("theme"); };

    swatches.forEach((s) => s.addEventListener("click", () => update({ accent: s.dataset.accent })));
    color.addEventListener("input", () => update({ accent: color.value }));
    bgs.forEach((b) => b.addEventListener("click", () => update({ bg: b.dataset.bg })));
    spotify.addEventListener("change", () => update({ spotify: spotify.checked }));
    render();
  },
});
