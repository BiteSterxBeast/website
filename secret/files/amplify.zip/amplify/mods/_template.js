// Template for your own Amplify mod.
//
// 1. Copy this file, e.g. mods/mymod.js, and change the id/name below.
// 2. Open manifest.json and add "mods/mymod.js" to the first content_scripts "js" list,
//    after "core.js" and before "ui.js".
// 3. Reload the extension in chrome://extensions and refresh Spotify.
//
// Your mod gets a tab in the Amplify toolbox and a switch in the Mods page.
// Useful things on the Amplify object (A):
//   A.store("mymod", defaults)  -> saved settings: .get(k) .set(k, v) .patch(obj) .all()
//   A.player.current            -> { title, artist, album, art } for the song playing now
//   A.player.next() / A.player.seek(seconds) / A.player.isPlaying()
//   A.media.set(rate, keepPitch) -> playback speed
//   A.on("track", fn)           -> runs when the song changes
//   A.ui.toast("Hello!")        -> small popup message
//   A.ui.range(input, value)    -> set a slider's value and update its fill

Amplify.register({
  id: "mymod",
  name: "My Mod",
  description: "What this mod does, shown in the Mods page.",
  // icon: `<svg viewBox="0 0 24 24" width="18" height="18" fill="currentColor">...</svg>`,

  // Runs once when Spotify loads, before the page is built
  init(A) {
    this.s = A.store("mymod", { count: 0 });
    A.on("track", (song) => {
      if (!A.isEnabled("mymod")) return;
      this.s.set("count", this.s.get("count") + 1);
    });
  },

  // Optional: run when the mod is switched on/off in the Mods page
  enable(A) {},
  disable(A) {},

  // Builds this mod's tab in the toolbox
  mount(root, A) {
    root.innerHTML = `
      <div class="amp-section">
        <h4>My Mod</h4>
        <div class="amp-big"><span>Songs played this session</span><b class="mm-count"></b></div>
        <button class="amp-chip mm-hello" style="width:100%">Say hi</button>
      </div>`;
    const render = () => (root.querySelector(".mm-count").textContent = this.s.get("count"));
    root.querySelector(".mm-hello").onclick = () => A.ui.toast("Hi from My Mod!");
    A.on("track", render);
    render();
  },
});
