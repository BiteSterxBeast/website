// Mod: Audio FX. Reverb, echo and 8D / 16D spatial audio.

Amplify.register({
  id: "fx",
  name: "Audio FX",
  tabName: "FX",
  description: "Reverb, echo and 8D / 16D audio that spins the song around your head.",
  needsEngine: true,
  icon: `<svg viewBox="0 0 24 24" width="18" height="18" fill="currentColor"><path d="M12 3a1 1 0 0 1 1 1v16a1 1 0 1 1-2 0V4a1 1 0 0 1 1-1zM7 7a1 1 0 0 1 1 1v8a1 1 0 1 1-2 0V8a1 1 0 0 1 1-1zm10 0a1 1 0 0 1 1 1v8a1 1 0 1 1-2 0V8a1 1 0 0 1 1-1zM2 10a1 1 0 0 1 1 1v2a1 1 0 1 1-2 0v-2a1 1 0 0 1 1-1zm20 0a1 1 0 0 1 1 1v2a1 1 0 1 1-2 0v-2a1 1 0 0 1 1-1z"/></svg>`,

  audioDefaults: { reverb: 0, room: 3, echo: 0, delay: 350, spatial: "off", spin: 8 },

  init(A) {
    this.s = A.store("fx", this.audioDefaults);
    A.audio.set("fx", this.s.all());
  },

  set(A, patch) {
    this.s.patch(patch);
    A.audio.set("fx", this.s.all());
    A.emit("fx:changed");
  },

  mount(root, A) {
    root.innerHTML = `
      <div class="amp-section">
        <h4>3D audio <span style="text-transform:none;letter-spacing:0;font-weight:500">· use headphones</span></h4>
        <div class="amp-grid c3">
          <button class="amp-chip" data-mode="off">Off</button>
          <button class="amp-chip" data-mode="8d">8D</button>
          <button class="amp-chip" data-mode="16d">16D</button>
        </div>
        <div class="amp-row" style="margin-top:10px">
          <div class="amp-row-top"><span>Spin speed</span><span data-out="spin"></span></div>
          <input type="range" data-k="spin" min="2" max="20" step="1" style="direction:rtl">
        </div>
      </div>

      <div class="amp-section">
        <h4>Reverb</h4>
        <div class="amp-row">
          <div class="amp-row-top"><span>Amount</span><span data-out="reverb"></span></div>
          <input type="range" data-k="reverb" min="0" max="100" step="1">
        </div>
        <div class="amp-row">
          <div class="amp-row-top"><span>Room size</span><span data-out="room"></span></div>
          <input type="range" data-k="room" min="1" max="6" step="0.5">
        </div>
      </div>

      <div class="amp-section">
        <h4>Echo</h4>
        <div class="amp-row">
          <div class="amp-row-top"><span>Amount</span><span data-out="echo"></span></div>
          <input type="range" data-k="echo" min="0" max="100" step="1">
        </div>
        <div class="amp-row">
          <div class="amp-row-top"><span>Delay</span><span data-out="delay"></span></div>
          <input type="range" data-k="delay" min="50" max="1000" step="10">
        </div>
      </div>

      <div class="amp-section">
        <h4>Presets</h4>
        <div class="amp-grid c2">
          <button class="amp-chip" data-preset="slowed">Slowed + Reverb</button>
          <button class="amp-chip" data-preset="nightcore">Nightcore</button>
          <button class="amp-chip" data-preset="8dchill">8D Chill</button>
          <button class="amp-chip" data-preset="reset">Reset FX</button>
        </div>
        <div class="amp-hint">Double-click any slider to reset it.</div>
      </div>`;

    const labels = {
      reverb: (v) => (v > 0 ? v + "%" : "Off"),
      room: (v) => Number(v).toFixed(1) + "s",
      echo: (v) => (v > 0 ? v + "%" : "Off"),
      delay: (v) => v + " ms",
      spin: (v) => v + "s per lap",
    };
    const sliders = root.querySelectorAll("input[data-k]");
    const modes = root.querySelectorAll("[data-mode]");

    const render = () => {
      const fx = this.s.all();
      sliders.forEach((s) => {
        A.ui.range(s, fx[s.dataset.k]);
        root.querySelector(`[data-out="${s.dataset.k}"]`).textContent = labels[s.dataset.k](fx[s.dataset.k]);
      });
      modes.forEach((b) => b.classList.toggle("active", b.dataset.mode === fx.spatial));
    };

    sliders.forEach((s) => {
      s.addEventListener("input", () => { this.set(A, { [s.dataset.k]: +s.value }); render(); });
      s.addEventListener("dblclick", () => { this.set(A, { [s.dataset.k]: this.audioDefaults[s.dataset.k] }); render(); });
    });
    modes.forEach((b) => b.addEventListener("click", () => { this.set(A, { spatial: b.dataset.mode }); render(); }));

    const speed = (rate) => A.isEnabled("speed") && A.media.set(rate, false);
    root.querySelectorAll("[data-preset]").forEach((b) =>
      b.addEventListener("click", () => {
        const p = b.dataset.preset;
        if (p === "slowed") { speed(0.85); this.set(A, { reverb: 45, room: 4, echo: 0, spatial: "off" }); }
        else if (p === "nightcore") { speed(1.25); this.set(A, { reverb: 10, room: 2, echo: 0, spatial: "off" }); }
        else if (p === "8dchill") { speed(0.9); this.set(A, { reverb: 30, room: 3.5, echo: 0, spatial: "8d", spin: 8 }); }
        else { this.set(A, { ...this.audioDefaults }); }
        render();
        A.ui.toast(b.textContent);
      })
    );
    render();
  },
});
