// Amplify audio engine (offscreen page).
// Receives the Spotify tab's audio and runs it through:
//   EQ -> volume boost -> 8D/16D -> reverb + echo -> limiter -> analyser (visualizer) -> speakers

let ctx = null;
let stream = null;
let n = null; // audio nodes
let fx = {
  reverb: 0, room: 3, echo: 0, delay: 350, spatial: "off", spin: 8,
  eq: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0], volume: 100,
};
let builtRoom = null;

const EQ_FREQS = [32, 64, 125, 250, 500, 1000, 2000, 4000, 8000, 16000];

chrome.runtime.onMessage.addListener((msg) => {
  if (msg.target === "offscreen" && msg.type === "start") start(msg.streamId, msg.fx);
  else if (msg.target === "offscreen" && msg.type === "stop") stop();
  else if (msg.type === "fx") {
    fx = { ...fx, ...msg.fx };
    apply();
  }
});

// ---------- Visualizer data, streamed to the Spotify tab ----------
chrome.runtime.onConnect.addListener((port) => {
  if (port.name !== "amplify-viz") return;
  const timer = setInterval(() => {
    const frame = vizFrame();
    if (frame) port.postMessage(frame);
  }, 33);
  port.onDisconnect.addListener(() => clearInterval(timer));
});

let fBuf = null, wBuf = null, binMap = null;
function vizFrame() {
  if (!ctx || !n) return null;
  const an = n.analyser;
  if (!fBuf) {
    fBuf = new Uint8Array(an.frequencyBinCount);
    wBuf = new Uint8Array(an.fftSize);
    // 64 log-spaced bands from 30 Hz to 16 kHz
    const hzPerBin = ctx.sampleRate / an.fftSize;
    binMap = [];
    for (let i = 0; i < 64; i++) {
      const lo = 30 * Math.pow(16000 / 30, i / 64);
      const hi = 30 * Math.pow(16000 / 30, (i + 1) / 64);
      const a = Math.max(1, Math.floor(lo / hzPerBin));
      const b = Math.max(a + 1, Math.ceil(hi / hzPerBin));
      binMap.push([a, Math.min(b, fBuf.length)]);
    }
  }
  an.getByteFrequencyData(fBuf);
  an.getByteTimeDomainData(wBuf);
  const f = new Array(64);
  for (let i = 0; i < 64; i++) {
    let m = 0;
    const [a, b] = binMap[i];
    for (let j = a; j < b; j++) if (fBuf[j] > m) m = fBuf[j];
    f[i] = m;
  }
  const w = new Array(128);
  const step = wBuf.length / 128;
  for (let i = 0; i < 128; i++) w[i] = wBuf[Math.floor(i * step)] - 128;
  return { f, w };
}

// ---------- Reverb impulse: stereo noise that fades out over `seconds` ----------
function makeImpulse(seconds) {
  const rate = ctx.sampleRate;
  const length = Math.max(1, Math.floor(rate * seconds));
  const buf = ctx.createBuffer(2, length, rate);
  const preDelay = Math.floor(rate * 0.02);
  for (let c = 0; c < 2; c++) {
    const data = buf.getChannelData(c);
    for (let i = preDelay; i < length; i++) {
      const t = (i - preDelay) / (length - preDelay);
      data[i] = (Math.random() * 2 - 1) * Math.pow(1 - t, 3);
    }
  }
  return buf;
}

async function start(streamId, initialFx) {
  stop();
  fx = { ...fx, ...(initialFx || {}) };

  stream = await navigator.mediaDevices.getUserMedia({
    audio: { mandatory: { chromeMediaSource: "tab", chromeMediaSourceId: streamId } },
    video: false,
  });

  ctx = new AudioContext({ latencyHint: "playback" });
  const src = ctx.createMediaStreamSource(stream);
  fBuf = wBuf = binMap = null;

  n = {
    eq: EQ_FREQS.map((f, i) => {
      const b = ctx.createBiquadFilter();
      b.type = i === 0 ? "lowshelf" : i === EQ_FREQS.length - 1 ? "highshelf" : "peaking";
      b.frequency.value = f;
      b.Q.value = 1.1;
      b.gain.value = 0;
      return b;
    }),
    volume: ctx.createGain(),
    // 8D / 16D
    bypass: ctx.createGain(),
    panner: ctx.createPanner(),
    spatialOut: ctx.createGain(),
    spatialSend: ctx.createGain(),
    oscX: ctx.createOscillator(),
    oscZ: ctx.createOscillator(),
    oscY: ctx.createOscillator(),
    yDepth: ctx.createGain(),
    bus: ctx.createGain(),
    // reverb / echo / output
    dry: ctx.createGain(),
    reverbSend: ctx.createGain(),
    convolver: ctx.createConvolver(),
    reverbOut: ctx.createGain(),
    delay: ctx.createDelay(2.0),
    feedback: ctx.createGain(),
    echoTone: ctx.createBiquadFilter(),
    echoWet: ctx.createGain(),
    limiter: ctx.createDynamicsCompressor(),
    analyser: ctx.createAnalyser(),
  };

  // EQ chain -> volume
  let node = src;
  n.eq.forEach((b) => { node.connect(b); node = b; });
  node.connect(n.volume);

  // 8D: the sound orbits around your head (HRTF = headphone 3D)
  const p = n.panner;
  p.panningModel = "HRTF";
  p.distanceModel = "inverse";
  p.refDistance = 1;
  p.positionX.value = 0;
  p.positionY.value = 0;
  p.positionZ.value = 0;
  n.oscX.type = "sine";
  n.oscZ.setPeriodicWave(ctx.createPeriodicWave(new Float32Array([0, 1]), new Float32Array([0, 0]))); // cosine
  n.oscX.connect(p.positionX);
  n.oscZ.connect(p.positionZ);
  n.oscY.type = "sine"; // 16D: also bob up and down
  n.oscY.connect(n.yDepth).connect(p.positionY);
  const t0 = ctx.currentTime + 0.05;
  n.oscX.start(t0);
  n.oscZ.start(t0);
  n.oscY.start(t0);

  n.volume.connect(n.bypass).connect(n.bus);
  n.volume.connect(p).connect(n.spatialOut).connect(n.bus);
  p.connect(n.spatialSend).connect(n.convolver); // extra room for 8D/16D

  // Echo tone + limiter
  n.echoTone.type = "lowpass";
  n.echoTone.frequency.value = 3500;
  n.limiter.threshold.value = -2;
  n.limiter.knee.value = 0;
  n.limiter.ratio.value = 20;
  n.limiter.attack.value = 0.003;
  n.limiter.release.value = 0.25;

  n.bus.connect(n.dry).connect(n.limiter);
  n.bus.connect(n.reverbSend).connect(n.convolver);
  n.convolver.connect(n.reverbOut).connect(n.limiter);
  n.bus.connect(n.delay);
  n.delay.connect(n.echoTone).connect(n.feedback).connect(n.delay);
  n.delay.connect(n.echoWet).connect(n.limiter);

  // Analyser for the visualizer, then out to the speakers
  n.analyser.fftSize = 2048;
  n.analyser.smoothingTimeConstant = 0.75;
  n.analyser.minDecibels = -90;
  n.analyser.maxDecibels = -15;
  n.limiter.connect(n.analyser).connect(ctx.destination);

  builtRoom = null;
  apply(true);

  stream.getAudioTracks()[0].addEventListener("ended", () => {
    chrome.runtime.sendMessage({ type: "captureEnded" }).catch(() => {});
  });
}

function apply(instant = false) {
  if (!ctx || !n) return;
  const now = ctx.currentTime;
  const set = (param, value) =>
    instant ? param.setValueAtTime(value, now) : param.setTargetAtTime(value, now, 0.05);

  const r = Math.min(1, Math.max(0, fx.reverb / 100));
  const e = Math.min(1, Math.max(0, fx.echo / 100));
  const mode = fx.spatial || "off";
  const extraRoom = mode === "16d" ? 0.35 : mode === "8d" ? 0.12 : 0;

  // EQ + volume
  const eq = Array.isArray(fx.eq) ? fx.eq : [];
  n.eq.forEach((b, i) => set(b.gain, Math.max(-12, Math.min(12, +eq[i] || 0))));
  set(n.volume.gain, Math.max(0, Math.min(3, (+fx.volume || 100) / 100)));

  if (builtRoom !== fx.room) {
    n.convolver.buffer = makeImpulse(fx.room);
    builtRoom = fx.room;
  }

  // 8D / 16D
  set(n.bypass.gain, mode === "off" ? 1 : 0);
  set(n.spatialOut.gain, mode === "off" ? 0 : 1);
  set(n.spatialSend.gain, extraRoom);
  set(n.yDepth.gain, mode === "16d" ? 0.8 : 0);
  const freq = 1 / Math.min(20, Math.max(2, fx.spin || 8));
  n.oscX.frequency.setValueAtTime(freq, now);
  n.oscZ.frequency.setValueAtTime(freq, now);
  n.oscY.frequency.setValueAtTime(freq * 0.5, now);

  // Reverb / echo
  set(n.dry.gain, 1 - 0.35 * Math.max(Math.min(1, r + extraRoom), e));
  set(n.reverbSend.gain, r);
  set(n.reverbOut.gain, 1.3);
  set(n.echoWet.gain, e * 0.8);
  set(n.feedback.gain, 0.2 + 0.45 * e);
  set(n.delay.delayTime, Math.min(1.9, Math.max(0.05, fx.delay / 1000)));
}

function stop() {
  if (stream) stream.getTracks().forEach((t) => t.stop());
  if (ctx) ctx.close().catch(() => {});
  stream = null;
  ctx = null;
  n = null;
}
