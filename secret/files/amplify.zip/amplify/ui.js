// Amplify UI: the player-bar button, the toolbox panel, the Mods manager and toasts.
// Loaded after all mods. Each mod supplies its own page through mod.mount(root, Amplify).

(() => {
  const A = window.Amplify;
  if (!A || A.__ui) return;
  A.__ui = true;

  const BOLT = `<svg viewBox="0 0 24 24" width="18" height="18" fill="currentColor" aria-hidden="true"><path d="M13.5 2 4 13.5h6.2L9 22l10-12h-6.4L13.5 2z"/></svg>`;
  const GEAR = `<svg viewBox="0 0 24 24" width="18" height="18" fill="currentColor" aria-hidden="true"><path d="M19.4 13a7.6 7.6 0 0 0 0-2l2.1-1.6-2-3.5-2.5 1a7.4 7.4 0 0 0-1.7-1L15 3.3h-4l-.4 2.6a7.4 7.4 0 0 0-1.7 1l-2.5-1-2 3.5L6.5 11a7.6 7.6 0 0 0 0 2l-2.1 1.6 2 3.5 2.5-1c.5.4 1.1.7 1.7 1l.4 2.6h4l.4-2.6c.6-.3 1.2-.6 1.7-1l2.5 1 2-3.5L19.4 13zM13 15.5a3.5 3.5 0 1 1 0-7 3.5 3.5 0 0 1 0 7z" transform="translate(-1 0)"/></svg>`;

  const CSS = `
    :root { --amp-accent: #1ed760; --amp-on-accent: #000; --amp-bg: #1f1f1f; --amp-card: #2a2a2a; --amp-track: #4d4d4d; --amp-text: #fff; --amp-sub: #a7a7a7; }

    #amp-btn {
      display: inline-flex; align-items: center; justify-content: center; gap: 3px;
      min-width: 32px; height: 32px; padding: 0 8px; margin-right: 4px;
      background: none; border: none; border-radius: 16px; cursor: pointer;
      color: #b3b3b3; font-family: inherit; font-size: 12px; font-weight: 700; line-height: 1;
      font-variant-numeric: tabular-nums; transition: color .15s, transform .1s;
    }
    #amp-btn:hover { color: #fff; transform: scale(1.05); }
    #amp-btn.active { color: var(--amp-accent); }
    #amp-btn.floating { position: fixed; right: 16px; bottom: 100px; z-index: 99999; background: #282828; box-shadow: 0 4px 12px rgba(0,0,0,.5); }

    #amp-panel {
      position: fixed; z-index: 99999; width: 344px; box-sizing: border-box;
      background: var(--amp-bg); color: var(--amp-text); border-radius: 12px;
      box-shadow: 0 16px 40px rgba(0,0,0,.6); border: 1px solid rgba(255,255,255,.06);
      font-family: inherit; font-size: 13px; display: none; flex-direction: column;
      max-height: calc(100vh - 110px); overflow: hidden;
    }
    #amp-panel.open { display: flex; }
    #amp-panel * { box-sizing: border-box; }

    #amp-panel .amp-top { display: flex; align-items: center; justify-content: space-between; padding: 14px 16px 10px; }
    #amp-panel .amp-brand { display: flex; align-items: center; gap: 6px; font-weight: 800; font-size: 16px; letter-spacing: -.2px; }
    #amp-panel .amp-brand svg { color: var(--amp-accent); }
    #amp-panel .amp-engine {
      display: inline-flex; align-items: center; gap: 6px; border: none; cursor: pointer;
      padding: 4px 10px; border-radius: 999px; background: var(--amp-card); color: var(--amp-sub);
      font-family: inherit; font-size: 11px; font-weight: 700; letter-spacing: .3px;
    }
    #amp-panel .amp-engine i { width: 7px; height: 7px; border-radius: 50%; background: #6a6a6a; }
    #amp-panel .amp-engine.on { color: var(--amp-text); }
    #amp-panel .amp-engine.on i { background: var(--amp-accent); box-shadow: 0 0 8px var(--amp-accent); }

    #amp-panel .amp-tabs { display: flex; gap: 2px; padding: 0 10px; border-bottom: 1px solid rgba(255,255,255,.07); }
    #amp-panel .amp-tab {
      flex: 1; display: flex; flex-direction: column; align-items: center; gap: 3px;
      padding: 6px 0 8px; border: none; background: none; cursor: pointer; color: var(--amp-sub);
      font-family: inherit; font-size: 10px; font-weight: 600; border-bottom: 2px solid transparent; margin-bottom: -1px;
    }
    #amp-panel .amp-tab:hover { color: var(--amp-text); }
    #amp-panel .amp-tab.active { color: var(--amp-text); border-bottom-color: var(--amp-accent); }
    #amp-panel .amp-tab.active svg { color: var(--amp-accent); }

    #amp-panel .amp-body { padding: 14px 16px; overflow-y: auto; flex: 1; scrollbar-width: thin; }
    #amp-panel .amp-page { display: none; }
    #amp-panel .amp-page.active { display: block; }

    #amp-panel .amp-note {
      margin: 0 16px 10px; padding: 8px 10px; border-radius: 8px; background: rgba(255,255,255,.05);
      color: var(--amp-sub); font-size: 11px; line-height: 1.45; display: none;
    }
    #amp-panel .amp-note.show { display: block; }
    #amp-panel .amp-note.err { color: #f3727f; }
    #amp-panel .amp-note b { color: var(--amp-text); }

    #amp-panel .amp-footer { padding: 10px 16px 14px; border-top: 1px solid rgba(255,255,255,.07); display: flex; flex-direction: column; gap: 8px; }
    #amp-panel .amp-footer:empty { display: none; }

    /* ---- shared components for mods ---- */
    #amp-panel h4 { margin: 0 0 8px; font-size: 11px; font-weight: 700; letter-spacing: .6px; text-transform: uppercase; color: var(--amp-sub); }
    #amp-panel .amp-section + .amp-section { margin-top: 16px; padding-top: 14px; border-top: 1px solid rgba(255,255,255,.07); }
    #amp-panel .amp-big { display: flex; justify-content: space-between; align-items: baseline; margin-bottom: 8px; }
    #amp-panel .amp-big b { font-size: 24px; font-weight: 800; font-variant-numeric: tabular-nums; }
    #amp-panel .amp-row { margin-bottom: 10px; }
    #amp-panel .amp-row-top { display: flex; justify-content: space-between; margin-bottom: 2px; color: #e0e0e0; }
    #amp-panel .amp-row-top span:last-child { color: var(--amp-sub); font-variant-numeric: tabular-nums; }
    #amp-panel .amp-scale { display: flex; justify-content: space-between; color: var(--amp-sub); font-size: 10px; }
    #amp-panel .amp-hint { color: var(--amp-sub); font-size: 11px; line-height: 1.45; margin-top: 10px; }
    #amp-panel .amp-grid { display: grid; gap: 6px; }
    #amp-panel .amp-grid.c2 { grid-template-columns: repeat(2, 1fr); }
    #amp-panel .amp-grid.c3 { grid-template-columns: repeat(3, 1fr); }
    #amp-panel .amp-grid.c4 { grid-template-columns: repeat(4, 1fr); }
    #amp-panel .amp-grid.c5 { grid-template-columns: repeat(5, 1fr); }

    #amp-panel .amp-chip {
      padding: 7px 4px; border: none; border-radius: 7px; cursor: pointer;
      background: var(--amp-card); color: var(--amp-text);
      font-family: inherit; font-size: 12px; font-weight: 600; line-height: 1.2; transition: background .12s;
    }
    #amp-panel .amp-chip:hover { background: #3a3a3a; }
    #amp-panel .amp-chip.active { background: var(--amp-accent); color: var(--amp-on-accent); }
    #amp-panel .amp-chip.danger:hover { background: #5a2329; }

    #amp-panel .amp-wide {
      width: 100%; display: flex; align-items: center; justify-content: center; gap: 8px;
      padding: 10px; border: none; border-radius: 999px; cursor: pointer;
      background: var(--amp-card); color: var(--amp-text); font-family: inherit; font-size: 13px; font-weight: 700;
      transition: background .12s, transform .1s;
    }
    #amp-panel .amp-wide:hover { background: #3a3a3a; transform: scale(1.01); }
    #amp-panel .amp-wide.active { background: var(--amp-accent); color: var(--amp-on-accent); }

    #amp-panel input[type=range] {
      -webkit-appearance: none; appearance: none; width: 100%; height: 18px; margin: 0;
      background: transparent; cursor: pointer; --a: 0%; --b: 50%;
    }
    #amp-panel input[type=range]::-webkit-slider-runnable-track {
      height: 4px; border-radius: 2px;
      background: linear-gradient(to right, var(--amp-track) var(--a), var(--amp-text) var(--a), var(--amp-text) var(--b), var(--amp-track) var(--b));
    }
    #amp-panel input[type=range]:hover::-webkit-slider-runnable-track {
      background: linear-gradient(to right, var(--amp-track) var(--a), var(--amp-accent) var(--a), var(--amp-accent) var(--b), var(--amp-track) var(--b));
    }
    #amp-panel input[type=range]::-webkit-slider-thumb {
      -webkit-appearance: none; appearance: none; width: 12px; height: 12px; margin-top: -4px;
      border-radius: 50%; background: #fff; box-shadow: 0 2px 4px rgba(0,0,0,.5); opacity: 0; transition: opacity .1s;
    }
    #amp-panel input[type=range]:hover::-webkit-slider-thumb,
    #amp-panel input[type=range]:active::-webkit-slider-thumb { opacity: 1; }

    #amp-panel .amp-toggle { display: flex; align-items: center; justify-content: space-between; gap: 10px; cursor: pointer; color: #e0e0e0; padding: 4px 0; }
    #amp-panel .amp-toggle input { display: none; }
    #amp-panel .amp-toggle i { flex: none; position: relative; width: 34px; height: 20px; border-radius: 10px; background: #535353; transition: background .15s; }
    #amp-panel .amp-toggle i::after { content: ""; position: absolute; top: 3px; left: 3px; width: 14px; height: 14px; border-radius: 50%; background: #fff; transition: transform .15s; }
    #amp-panel .amp-toggle input:checked + i { background: var(--amp-accent); }
    #amp-panel .amp-toggle input:checked + i::after { transform: translateX(14px); background: var(--amp-on-accent); }

    /* ---- Mods manager ---- */
    #amp-panel .amp-mod { display: flex; gap: 10px; align-items: flex-start; padding: 10px; border-radius: 10px; background: var(--amp-card); margin-bottom: 8px; }
    #amp-panel .amp-mod-icon { flex: none; width: 32px; height: 32px; border-radius: 8px; display: grid; place-items: center; background: rgba(255,255,255,.06); color: var(--amp-accent); }
    #amp-panel .amp-mod-text { flex: 1; min-width: 0; }
    #amp-panel .amp-mod-text b { display: block; font-size: 13px; margin-bottom: 2px; }
    #amp-panel .amp-mod-text span { color: var(--amp-sub); font-size: 11px; line-height: 1.4; }
    #amp-panel .amp-mod .amp-toggle { padding: 0; }
    #amp-panel .amp-tag { display: inline-block; margin-top: 4px; font-size: 10px; font-weight: 700; color: var(--amp-sub); background: rgba(255,255,255,.06); padding: 1px 6px; border-radius: 4px; }

    #amp-toast {
      position: fixed; left: 50%; bottom: 110px; transform: translate(-50%, 10px); z-index: 100000;
      background: #fff; color: #000; padding: 9px 16px; border-radius: 8px; font-family: inherit;
      font-size: 13px; font-weight: 600; box-shadow: 0 8px 24px rgba(0,0,0,.4);
      opacity: 0; pointer-events: none; transition: opacity .2s, transform .2s;
    }
    #amp-toast.show { opacity: 1; transform: translate(-50%, 0); }
  `;

  function build() {
    const style = document.createElement("style");
    style.id = "amp-style";
    style.textContent = CSS;
    document.head.appendChild(style);

    const btn = A.ui.el(`<button id="amp-btn" title="Amplify">${BOLT}<span></span></button>`);
    const btnLabel = btn.querySelector("span");

    const panel = A.ui.el(`
      <div id="amp-panel">
        <div class="amp-top">
          <div class="amp-brand">${BOLT}Amplify</div>
          <button class="amp-engine" title="The audio engine powers reverb, 8D, EQ and the visualizer"><i></i><span>ENGINE OFF</span></button>
        </div>
        <div class="amp-tabs"></div>
        <div class="amp-body"></div>
        <div class="amp-note"></div>
        <div class="amp-footer"></div>
      </div>`);
    document.body.appendChild(panel);

    const toast = A.ui.el(`<div id="amp-toast"></div>`);
    document.body.appendChild(toast);
    let toastTimer;
    A.on("toast", (text) => {
      toast.textContent = text;
      const host = document.fullscreenElement || document.body;
      if (toast.parentElement !== host) host.appendChild(toast);
      toast.classList.add("show");
      clearTimeout(toastTimer);
      toastTimer = setTimeout(() => toast.classList.remove("show"), 2200);
    });

    const tabsEl = panel.querySelector(".amp-tabs");
    const body = panel.querySelector(".amp-body");
    const footer = panel.querySelector(".amp-footer");
    const note = panel.querySelector(".amp-note");
    const engineBtn = panel.querySelector(".amp-engine");

    // Keep every slider's fill in sync as it's dragged
    panel.addEventListener("input", (e) => {
      if (e.target.matches("input[type=range]")) A.ui.range(e.target);
    });

    const prefs = A.store("ui", { tab: "speed" });
    const pages = {}; // id -> page element
    const mounted = new Set();
    let showEngineHelp = false;

    // Built-in "Mods" page
    const modsPage = A.ui.el(`<div class="amp-page" data-page="mods"></div>`);
    body.appendChild(modsPage);
    pages.mods = modsPage;

    function renderModsPage() {
      modsPage.innerHTML = `<h4>Installed mods</h4>`;
      A.mods.forEach((m) => {
        const row = A.ui.el(`
          <div class="amp-mod">
            <div class="amp-mod-icon">${m.icon || BOLT}</div>
            <div class="amp-mod-text"><b></b><span></span>${m.needsEngine ? '<br><span class="amp-tag">Uses audio engine</span>' : ""}</div>
            <label class="amp-toggle"><input type="checkbox"><i></i></label>
          </div>`);
        row.querySelector("b").textContent = m.name;
        row.querySelector(".amp-mod-text > span").textContent = m.description || "";
        const cb = row.querySelector("input");
        cb.checked = A.isEnabled(m.id);
        cb.addEventListener("change", () => A.setEnabled(m.id, cb.checked));
        modsPage.appendChild(row);
      });
      const reset = A.ui.el(`<button class="amp-chip danger" style="width:100%;margin-top:6px">Reset all Amplify settings</button>`);
      reset.addEventListener("click", () => {
        if (reset.dataset.armed) { A.resetAll(); location.reload(); return; }
        reset.dataset.armed = "1";
        reset.textContent = "Click again to reset and reload";
        setTimeout(() => { delete reset.dataset.armed; reset.textContent = "Reset all Amplify settings"; }, 3000);
      });
      modsPage.appendChild(reset);
      modsPage.appendChild(A.ui.el(`<div class="amp-hint">Want to make your own mod? Copy <b>mods/_template.js</b>, then add it to the list in <b>manifest.json</b>.</div>`));
    }

    function mountMods() {
      A.mods.forEach((m) => {
        if (mounted.has(m.id) || !m.mount) return;
        mounted.add(m.id);
        if (m.slot === "footer") {
          const holder = A.ui.el(`<div data-footer="${m.id}"></div>`);
          footer.appendChild(holder);
          pages[m.id] = holder;
          try { m.mount(holder, A); } catch (e) { console.error("[Amplify] mount failed:", m.id, e); }
        } else {
          const page = A.ui.el(`<div class="amp-page" data-page="${m.id}"></div>`);
          body.insertBefore(page, modsPage);
          pages[m.id] = page;
          try { m.mount(page, A); } catch (e) { console.error("[Amplify] mount failed:", m.id, e); }
        }
      });
      panel.querySelectorAll("input[type=range]").forEach((r) => A.ui.range(r));
    }

    function currentTab() {
      const visible = A.mods.filter((m) => m.slot !== "footer" && m.mount && A.isEnabled(m.id)).map((m) => m.id);
      return visible.includes(prefs.get("tab")) || prefs.get("tab") === "mods" ? prefs.get("tab") : visible[0] || "mods";
    }

    function renderTabs() {
      tabsEl.innerHTML = "";
      const active = currentTab();
      const tabMods = A.mods.filter((m) => m.slot !== "footer" && m.mount && A.isEnabled(m.id));
      [...tabMods, { id: "mods", name: "Mods", icon: GEAR }].forEach((m) => {
        const t = A.ui.el(`<button class="amp-tab" data-tab="${m.id}">${m.icon || BOLT}<span></span></button>`);
        t.querySelector("span").textContent = m.tabName || m.name;
        t.title = m.name;
        t.classList.toggle("active", m.id === active);
        t.addEventListener("click", () => { prefs.set("tab", m.id); renderAll(); });
        tabsEl.appendChild(t);
      });
      Object.entries(pages).forEach(([id, el]) => {
        if (el.classList.contains("amp-page")) el.classList.toggle("active", id === active);
        else el.style.display = A.isEnabled(id) ? "" : "none";
      });
    }

    function renderEngine() {
      engineBtn.classList.toggle("on", A.engine.on);
      engineBtn.querySelector("span").textContent = A.engine.on ? "ENGINE ON" : "ENGINE OFF";
      const mod = A.mods.find((m) => m.id === currentTab());
      const needs = mod && mod.needsEngine && A.isEnabled(mod.id);
      note.classList.remove("err");
      if (A.engine.error) {
        note.textContent = "Couldn't start the audio engine: " + A.engine.error;
        note.classList.add("err", "show");
      } else if (!A.engine.on && (needs || showEngineHelp)) {
        note.innerHTML = "This needs the <b>audio engine</b>. Click the <b>Amplify icon in Chrome's toolbar</b> to turn it on (once each time you open Spotify).";
        note.classList.add("show");
      } else if (A.engine.on && showEngineHelp) {
        note.innerHTML = "The audio engine is running. Click the Amplify icon in Chrome's toolbar again to turn it off.";
        note.classList.add("show");
      } else {
        note.classList.remove("show");
      }
    }

    function renderButton() {
      const changed = Math.abs(A.media.rate - 1) > 0.001 && A.isEnabled("speed");
      btn.classList.toggle("active", changed || A.engine.on);
      btnLabel.textContent = changed ? A.media.rate.toFixed(2).replace(/0$/, "") + "x" : "";
      btn.title = "Amplify" + (changed ? ` · ${A.media.rate.toFixed(2)}x` : "") + (A.engine.on ? " · engine on" : "");
    }

    function renderAll() {
      mountMods();
      renderModsPage();
      renderTabs();
      renderEngine();
      renderButton();
    }

    engineBtn.addEventListener("click", () => { showEngineHelp = !showEngineHelp; renderEngine(); });
    A.on("engine", () => { renderEngine(); renderButton(); });
    A.on("speed", renderButton);
    A.on("mods", renderAll);

    // Open/close. The toolbox opens above whichever button was clicked
    // (the player-bar button, or the visualizer's fullscreen bar).
    let anchor = btn;
    function positionPanel() {
      const r = anchor.getBoundingClientRect();
      panel.style.left = Math.min(window.innerWidth - 360, Math.max(16, r.left + r.width / 2 - 172)) + "px";
      panel.style.bottom = Math.max(16, window.innerHeight - r.top + 10) + "px";
    }
    function toggleToolbox(from, force) {
      const open = force !== undefined ? force : !panel.classList.contains("open") || anchor !== from;
      anchor = from || btn;
      // In fullscreen only the fullscreen element is visible, so the panel has to live inside it
      const host = document.fullscreenElement || document.body;
      if (panel.parentElement !== host) host.appendChild(panel);
      if (open) { positionPanel(); A.toExt("getStatus"); renderAll(); }
      panel.classList.toggle("open", open);
      A.emit("toolbox", open);
    }
    A.ui.toggleToolbox = toggleToolbox;
    A.ui.isToolboxOpen = () => panel.classList.contains("open");
    btn.addEventListener("click", (e) => { e.stopPropagation(); toggleToolbox(btn); });
    document.addEventListener("mousedown", (e) => {
      if (!panel.classList.contains("open")) return;
      if (panel.contains(e.target) || btn.contains(e.target) || e.target.closest("[data-amp-toolbox]")) return;
      toggleToolbox(anchor, false);
    });
    document.addEventListener("fullscreenchange", () => {
      // Move the panel back out when leaving fullscreen
      if (!document.fullscreenElement && panel.parentElement !== document.body) document.body.appendChild(panel);
      if (panel.classList.contains("open")) toggleToolbox(btn, false);
    });
    window.addEventListener("resize", () => panel.classList.contains("open") && positionPanel());

    // Put the button next to Spotify's volume bar; Spotify re-renders a lot, so keep re-attaching
    function place() {
      if (btn.isConnected && !btn.classList.contains("floating")) return;
      const vol = document.querySelector('[data-testid="volume-bar"]');
      if (vol && vol.parentElement) {
        btn.classList.remove("floating");
        vol.parentElement.insertBefore(btn, vol);
      }
    }
    new MutationObserver(place).observe(document.body, { childList: true, subtree: true });
    place();
    setTimeout(() => {
      if (!btn.isConnected) { btn.classList.add("floating"); document.body.appendChild(btn); }
    }, 8000);

    // Alt+A opens the toolbox
    document.addEventListener("keydown", (e) => {
      if (e.altKey && !e.ctrlKey && !e.metaKey && (e.key === "a" || e.key === "A")) {
        e.preventDefault();
        const fsBtn = document.fullscreenElement && document.fullscreenElement.querySelector("[data-amp-toolbox]");
        toggleToolbox(fsBtn || btn);
      }
    }, true);

    renderAll();
    A.audio.push();
    A.toExt("getStatus");
  }

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", build);
  else build();
})();
