// Bridge between the page (core.js and mods, which can't use chrome.* APIs)
// and the rest of the extension (background + audio engine).

const post = (type, payload) => window.postMessage({ __amp: "toPage", type, payload }, "*");

let vizWanted = false;
let vizPort = null;

function connectViz() {
  if (vizPort || !vizWanted) return;
  try {
    vizPort = chrome.runtime.connect({ name: "amplify-viz" });
  } catch {
    vizPort = null;
    return;
  }
  vizPort.onMessage.addListener((frame) => post("viz", frame));
  vizPort.onDisconnect.addListener(() => {
    void chrome.runtime.lastError;
    vizPort = null;
  });
}
function disconnectViz() {
  if (vizPort) { try { vizPort.disconnect(); } catch {} }
  vizPort = null;
}

window.addEventListener("message", (e) => {
  if (e.source !== window || !e.data || e.data.__amp !== "toExt") return;
  const { type, payload } = e.data;

  if (type === "audio") {
    chrome.runtime.sendMessage({ type: "fx", fx: payload }).catch(() => {});
  } else if (type === "getStatus") {
    chrome.runtime
      .sendMessage({ type: "getStatus" })
      .then((r) => post("status", { on: !!(r && r.on) }))
      .catch(() => post("status", { on: false }));
  } else if (type === "translate") {
    chrome.runtime
      .sendMessage({ type: "translate", texts: payload.texts, target: payload.target })
      .then((r) => post("translated", { key: payload.key, out: r && r.out, error: r && r.error }))
      .catch((e) => post("translated", { key: payload.key, error: String(e) }));
  } else if (type === "viz") {
    vizWanted = !!(payload && payload.on);
    vizWanted ? connectViz() : disconnectViz();
  }
});

chrome.runtime.onMessage.addListener((msg) => {
  if (msg.type === "fxStatus") {
    post("status", { on: msg.on });
    if (msg.on) setTimeout(connectViz, 250);
    else disconnectViz();
  } else if (msg.type === "fxError") {
    post("error", { message: msg.message });
  }
});
